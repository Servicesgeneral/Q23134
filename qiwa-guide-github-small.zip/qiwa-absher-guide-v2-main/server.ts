import dotenv from 'dotenv';
import express from 'express';
import type { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

dotenv.config();

type PlatformFilter = 'all' | 'qiwa' | 'absher' | 'nafath';
type LanguageCode = 'ar' | 'en' | 'ur' | 'bn';

interface NewsUpdateItem {
  id: string;
  platform: 'qiwa' | 'absher' | 'nafath';
  title: string;
  summary: string;
  dateLabel: string;
  category: string;
  sourceUrl: string;
}

interface GroundingSource {
  title: string;
  uri: string;
}

interface NewsApiResponse {
  items: NewsUpdateItem[];
  sources: GroundingSource[];
  fetchedAt: string;
  cached: boolean;
}

interface CacheEntry {
  data: NewsApiResponse;
  expiresAt: number;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const CACHE_TTL_MS = 10 * 60 * 1000;
const newsCache = new Map<string, CacheEntry>();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

const LANGUAGE_NAMES: Record<LanguageCode, string> = {
  ar: 'Arabic (Modern Standard Arabic)',
  en: 'English',
  ur: 'Urdu',
  bn: 'Bengali',
};

const PLATFORM_TOPICS: Record<PlatformFilter, string> = {
  all: 'Qiwa (قوى / qiwa.sa / hrsd.gov.sa), Absher (أبشر / absher.sa / moi.gov.sa), and Nafath (نفاذ / iam.gov.sa / sdaia.gov.sa)',
  qiwa: 'Qiwa platform (منصة قوى / qiwa.sa) and Saudi Ministry of Human Resources and Social Development (hrsd.gov.sa)',
  absher: 'Absher platform (منصة أبشر / absher.sa) and Saudi Ministry of Interior / Jawazat / Traffic / Civil Affairs',
  nafath: 'Nafath National Single Sign-On platform (منصة نفاذ / iam.gov.sa) and SDAIA (sdaia.gov.sa)',
};

const PLATFORM_DEFAULT_URL: Record<'qiwa' | 'absher' | 'nafath', string> = {
  qiwa: 'https://www.qiwa.sa',
  absher: 'https://www.absher.sa',
  nafath: 'https://www.iam.gov.sa',
};

function sanitizePlatform(val: unknown): PlatformFilter {
  if (val === 'qiwa' || val === 'absher' || val === 'nafath') return val;
  return 'all';
}

function sanitizeLang(val: unknown): LanguageCode {
  if (val === 'ar' || val === 'en' || val === 'ur' || val === 'bn') return val;
  return 'ar';
}

function normalizePlatformValue(raw: unknown, fallback: PlatformFilter): 'qiwa' | 'absher' | 'nafath' {
  const str = String(raw || '').toLowerCase();
  if (str.includes('qiwa') || str.includes('قوى')) return 'qiwa';
  if (str.includes('absher') || str.includes('أبشر') || str.includes('ابشر')) return 'absher';
  if (str.includes('nafath') || str.includes('نفاذ')) return 'nafath';
  return fallback === 'all' ? 'qiwa' : fallback;
}

function extractJsonArray(rawText: string): unknown[] | null {
  const trimmed = rawText.trim();
  const fencedMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fencedMatch ? fencedMatch[1].trim() : trimmed;

  const startIdx = candidate.indexOf('[');
  const endIdx = candidate.lastIndexOf(']');
  if (startIdx === -1 || endIdx === -1 || endIdx <= startIdx) {
    return null;
  }

  try {
    const parsed = JSON.parse(candidate.slice(startIdx, endIdx + 1));
    return Array.isArray(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

async function fetchGroundedNews(
  platform: PlatformFilter,
  lang: LanguageCode,
): Promise<NewsApiResponse> {
  const targetLangName = LANGUAGE_NAMES[lang];
  const targetTopic = PLATFORM_TOPICS[platform];
  const todayIso = new Date().toISOString().slice(0, 10);

  const prompt = `Today's date is ${todayIso}. Use Google Search to find the most recent official updates, newly launched e-services, regulatory announcements, or system notices from Saudi digital government platforms: ${targetTopic}.

Focus on verified recent announcements, service launches, policy changes, or official portal updates (such as new Absher services, Qiwa contract/labor/Nitaqat updates, or Nafath authentication updates).

Return ONLY a valid JSON array containing 5 to 6 distinct news items. Every text field ("title", "summary", "dateLabel", "category") MUST be written clearly and naturally in ${targetLangName}.
Each object in the JSON array must have exactly these fields:
- "platform": one of "qiwa", "absher", or "nafath"
- "title": concise headline (max 110 characters)
- "summary": factual 2-sentence summary explaining what changed and who benefits
- "dateLabel": publication date or timeframe found in search results (e.g., "2026" or exact month/date)
- "category": short 1-3 word topic label (e.g., labor regulations, digital ID, e-services)
- "sourceUrl": direct URL from the search result or the official platform domain

Do not invent updates. Rely strictly on Google Search results.`;

  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
    },
  });

  const rawText = response.text ?? '';
  const rawChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];

  const sourceMap = new Map<string, GroundingSource>();
  for (const chunk of rawChunks) {
    const uri = chunk.web?.uri;
    const title = chunk.web?.title;
    if (uri && !sourceMap.has(uri)) {
      sourceMap.set(uri, {
        uri,
        title: title || uri,
      });
    }
  }
  const sources = Array.from(sourceMap.values()).slice(0, 8);

  const parsedArray = extractJsonArray(rawText);
  let items: NewsUpdateItem[] = [];

  if (parsedArray && parsedArray.length > 0) {
    items = parsedArray
      .map((entry, idx) => {
        const obj = (entry ?? {}) as Record<string, unknown>;
        const itemPlatform = normalizePlatformValue(obj.platform, platform);
        const title = String(obj.title || '').trim();
        const summary = String(obj.summary || '').trim();
        if (!title || !summary) return null;

        const rawUrl = String(obj.sourceUrl || '').trim();
        const sourceUrl =
          rawUrl.startsWith('http://') || rawUrl.startsWith('https://')
            ? rawUrl
            : sources[idx]?.uri || PLATFORM_DEFAULT_URL[itemPlatform];

        return {
          id: `${itemPlatform}-${idx}-${Date.now()}`,
          platform: itemPlatform,
          title,
          summary,
          dateLabel: String(obj.dateLabel || todayIso).trim(),
          category: String(obj.category || itemPlatform.toUpperCase()).trim(),
          sourceUrl,
        };
      })
      .filter((item): item is NewsUpdateItem => item !== null);
  }

  if (items.length === 0 && rawText.trim().length > 0) {
    const fallbackPlatform = platform === 'all' ? 'qiwa' : platform;
    items = [
      {
        id: `${fallbackPlatform}-summary-${Date.now()}`,
        platform: fallbackPlatform,
        title:
          lang === 'ar'
            ? 'ملخص التحديثات الرسمية المستخلصة من البحث'
            : 'Grounded Official Updates Summary',
        summary: rawText.replace(/```[\s\S]*?```/g, '').trim().slice(0, 500),
        dateLabel: todayIso,
        category: lang === 'ar' ? 'تحديثات رسمية' : 'Official Updates',
        sourceUrl: sources[0]?.uri || PLATFORM_DEFAULT_URL[fallbackPlatform],
      },
    ];
  }

  return {
    items,
    sources,
    fetchedAt: new Date().toISOString(),
    cached: false,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  app.use('/api', (req: Request, res: Response, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') {
      res.status(204).end();
      return;
    }
    next();
  });

  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.get('/api/news', async (req: Request, res: Response) => {
    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'Missing GEMINI_API_KEY configuration on server.',
      });
      return;
    }

    const platform = sanitizePlatform(req.query.platform);
    const lang = sanitizeLang(req.query.lang);
    const forceRefresh = req.query.refresh === '1';
    const cacheKey = `${platform}:${lang}`;

    if (!forceRefresh) {
      const cached = newsCache.get(cacheKey);
      if (cached && cached.expiresAt > Date.now()) {
        res.json({
          ...cached.data,
          cached: true,
        });
        return;
      }
    }

    try {
      const result = await fetchGroundedNews(platform, lang);
      newsCache.set(cacheKey, {
        data: result,
        expiresAt: Date.now() + CACHE_TTL_MS,
      });
      res.json(result);
    } catch (err: unknown) {
      const errorObj = err as { status?: number; message?: string };
      let status =
        typeof errorObj?.status === 'number' && errorObj.status >= 400
          ? errorObj.status
          : 500;
      let message =
        errorObj?.message || 'Failed to fetch grounded platform updates.';
      let errorCode = '';

      try {
        const parsed = JSON.parse(message) as {
          error?: { code?: number; message?: string; status?: string };
        };
        if (parsed?.error) {
          if (typeof parsed.error.code === 'number') status = parsed.error.code;
          if (parsed.error.message) message = parsed.error.message;
          if (parsed.error.status) errorCode = parsed.error.status;
        }
      } catch {
        // Keep plain message string
      }

      res.status(status).json({ error: message, code: errorCode });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
