# Development notes — refreshed edition

## What changed
- Added an Arabic-friendly search normalizer (tashkeel, tatweel, alef variants, yaa/alif maqsura) so common spelling variants match the same service.
- Added a keyboard-accessible skip link and a focus target for the main content.
- Refreshed the visual system with a restrained Saudi-government-inspired green palette, calmer surfaces, improved focus states, subtle card depth, and reduced-motion support.
- Allowed normal pinch zoom by removing the restrictive `user-scalable=no` viewport setting.
- Added browser theme metadata and Open Graph locale metadata.
- Added `rel="noopener noreferrer"` to external links opened in a new tab.
- Synced the visual CSS layer and HTML metadata into the existing Android web asset bundle so the included native project reflects the visual refresh immediately.

## Build locally
Use Node.js 22 or a compatible current LTS release:

```bash
npm install
npm run lint
npm run build
npm run android:sync
```

Open `android/` in Android Studio to build a debug APK, or use the repository GitHub Actions workflow for CI builds.

## Before publishing
- Replace the Google AdMob sample/test identifiers in `admob-settings.json` with the publisher's own approved IDs only after the AdMob app is registered.
- Keep `isTesting: true` while testing. Set it to `false` only for a correctly configured production release.
- Configure a privacy policy and complete Google Play Data safety / ads declarations.
- Configure release signing with a private keystore and GitHub secrets. Never commit keystore files or passwords.
- Verify every external service URL and current procedural requirement before publishing; this app is an independent guide and is not an official Saudi government application.

## Build verification note
The source and Android project are included. A syntax-only transpilation check passed for every TypeScript/TSX source file. Dependency installation was attempted in the packaging environment but did not complete, so full TypeScript type-checking and a fresh Vite/Gradle build could not be verified here. Run the commands above on a machine with npm registry access before release.
