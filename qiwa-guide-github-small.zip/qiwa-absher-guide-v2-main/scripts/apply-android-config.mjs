import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '..');

const settingsPath = path.join(rootDir, 'admob-settings.json');
if (!fs.existsSync(settingsPath)) {
  throw new Error('Missing admob-settings.json at repository root.');
}

const settings = JSON.parse(fs.readFileSync(settingsPath, 'utf8'));

const appName = String(settings.appName || 'دليل خدمات قوى وأبشر ونفاذ').trim();
const androidPackageId = String(settings.androidPackageId || 'com.saudiguide.services').trim();
const versionName = String(settings.versionName || '1.0.0').trim();
const versionCode = Number(settings.versionCode) || 1;
const admobAppId = String(settings.admobAppId || 'ca-app-pub-3940256099942544~3347511713').trim();
const bannerAdId = String(settings.bannerAdId || 'ca-app-pub-3940256099942544/6300978111').trim();
const interstitialAdId = String(settings.interstitialAdId || 'ca-app-pub-3940256099942544/1033173712').trim();
const isTesting = Boolean(settings.isTesting);
const newsApiBaseUrl = String(settings.newsApiBaseUrl || '').trim().replace(/\/+$/, '');

function escapeSingleQuote(value) {
  return value.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

function escapeXml(value) {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// 1. Sync src/config/admobRuntimeConfig.ts
const runtimeConfigContent = `export interface AdMobRuntimeConfig {
  appName: string;
  androidPackageId: string;
  admobAppId: string;
  bannerAdId: string;
  interstitialAdId: string;
  isTesting: boolean;
  newsApiBaseUrl: string;
}

// Auto-synced from /admob-settings.json during Android/GitHub builds
export const AD_CONFIG: AdMobRuntimeConfig = {
  appName: '${escapeSingleQuote(appName)}',
  androidPackageId: '${escapeSingleQuote(androidPackageId)}',
  admobAppId: '${escapeSingleQuote(admobAppId)}',
  bannerAdId: '${escapeSingleQuote(bannerAdId)}',
  interstitialAdId: '${escapeSingleQuote(interstitialAdId)}',
  isTesting: ${isTesting},
  newsApiBaseUrl: '${escapeSingleQuote(newsApiBaseUrl)}',
};
`;
fs.writeFileSync(path.join(rootDir, 'src/config/admobRuntimeConfig.ts'), runtimeConfigContent, 'utf8');

// 2. Sync capacitor.config.ts
const capConfigContent = `import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: '${escapeSingleQuote(androidPackageId)}',
  appName: '${escapeSingleQuote(appName)}',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  plugins: {
    AdMob: {
      appId: '${escapeSingleQuote(admobAppId)}',
    },
  },
};

export default config;
`;
fs.writeFileSync(path.join(rootDir, 'capacitor.config.ts'), capConfigContent, 'utf8');

// 3. Patch Android native files if android/ exists
const androidDir = path.join(rootDir, 'android');
if (fs.existsSync(androidDir)) {
  // 3a. strings.xml
  const stringsPath = path.join(androidDir, 'app/src/main/res/values/strings.xml');
  if (fs.existsSync(stringsPath)) {
    const stringsXml = `<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">${escapeXml(appName)}</string>
    <string name="title_activity_main">${escapeXml(appName)}</string>
    <string name="package_name">${escapeXml(androidPackageId)}</string>
    <string name="custom_url_scheme">${escapeXml(androidPackageId)}</string>
    <string name="admob_app_id">${escapeXml(admobAppId)}</string>
</resources>
`;
    fs.writeFileSync(stringsPath, stringsXml, 'utf8');
  }

  // 3b. AndroidManifest.xml (add AdMob APPLICATION_ID + AD_ID permission)
  const manifestPath = path.join(androidDir, 'app/src/main/AndroidManifest.xml');
  if (fs.existsSync(manifestPath)) {
    let manifest = fs.readFileSync(manifestPath, 'utf8');

    if (!manifest.includes('com.google.android.gms.ads.APPLICATION_ID')) {
      manifest = manifest.replace(
        '</application>',
        `        <meta-data\n            android:name="com.google.android.gms.ads.APPLICATION_ID"\n            android:value="@string/admob_app_id" />\n    </application>`,
      );
    }

    if (!manifest.includes('com.google.android.gms.permission.AD_ID')) {
      manifest = manifest.replace(
        '<uses-permission android:name="android.permission.INTERNET" />',
        `<uses-permission android:name="android.permission.INTERNET" />\n    <uses-permission android:name="com.google.android.gms.permission.AD_ID" />`,
      );
    }

    fs.writeFileSync(manifestPath, manifest, 'utf8');
  }

  // 3c. variables.gradle -> keep Capacitor 8 SDK 36 defaults (meets Google Play API 35+ mandate)
  const variablesPath = path.join(androidDir, 'variables.gradle');
  if (fs.existsSync(variablesPath)) {
    let vars = fs.readFileSync(variablesPath, 'utf8');
    vars = vars.replace(/compileSdkVersion\s*=\s*\d+/, 'compileSdkVersion = 36');
    vars = vars.replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 36');
    vars = vars.replace(/minSdkVersion\s*=\s*\d+/, 'minSdkVersion = 24');
    fs.writeFileSync(variablesPath, vars, 'utf8');
  }

  // 3d. app/build.gradle -> update namespace, applicationId, versionCode, versionName, and release signing
  const appGradlePath = path.join(androidDir, 'app/build.gradle');
  if (fs.existsSync(appGradlePath)) {
    let gradle = fs.readFileSync(appGradlePath, 'utf8');
    gradle = gradle.replace(/namespace\s*=\s*"[^"]+"/, `namespace = "${androidPackageId}"`);
    gradle = gradle.replace(/applicationId\s+"[^"]+"/, `applicationId "${androidPackageId}"`);
    gradle = gradle.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
    gradle = gradle.replace(/versionName\s+"[^"]+"/, `versionName "${versionName}"`);

    if (!gradle.includes('signingConfigs')) {
      const signingBlock = `    signingConfigs {
        release {
            def ksPath = System.getenv("KEYSTORE_FILE")
            if (ksPath != null && !ksPath.isEmpty() && file(ksPath).exists()) {
                storeFile file(ksPath)
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }
    buildTypes {`;
      gradle = gradle.replace(/\s*buildTypes\s*\{/, `\n${signingBlock}`);
      gradle = gradle.replace(
        /buildTypes\s*\{\s*release\s*\{/,
        `buildTypes {\n        release {\n            def ksReleasePath = System.getenv("KEYSTORE_FILE")\n            if (ksReleasePath != null && !ksReleasePath.isEmpty()) {\n                signingConfig signingConfigs.release\n            }`,
      );
    }

    fs.writeFileSync(appGradlePath, gradle, 'utf8');
  }
}

console.log('Applied Android & AdMob configuration:', {
  appName,
  androidPackageId,
  versionCode,
  versionName,
  isTesting,
});
