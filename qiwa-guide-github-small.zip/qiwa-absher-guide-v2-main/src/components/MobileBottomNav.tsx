import React, { useEffect, useState } from 'react';
import {
  GitBranch,
  HelpCircle,
  LayoutGrid,
  Newspaper,
  Table2,
} from 'lucide-react';
import { LanguageCode } from '../types/guide';
import { NEWS_STRINGS } from '../data/newsStrings';
import { UI_STRINGS } from '../data/uiStrings';

interface MobileBottomNavProps {
  lang: LanguageCode;
  bannerHeight: number;
}

type SectionId = 'directory' | 'updates' | 'journeys' | 'comparison' | 'faq';

const SHORT_MOBILE_LABELS: Record<LanguageCode, Record<SectionId, string>> = {
  ar: {
    directory: 'الخدمات',
    updates: 'الأخبار',
    journeys: 'المسارات',
    comparison: 'المقارنة',
    faq: 'الأسئلة',
  },
  en: {
    directory: 'Services',
    updates: 'News',
    journeys: 'Journeys',
    comparison: 'Compare',
    faq: 'FAQ',
  },
  ur: {
    directory: 'خدمات',
    updates: 'خبریں',
    journeys: 'مراحل',
    comparison: 'موازنہ',
    faq: 'سوالات',
  },
  bn: {
    directory: 'সেবা',
    updates: 'সংবাদ',
    journeys: 'ধাপ',
    comparison: 'তুলনা',
    faq: 'প্রশ্ন',
  },
};

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  lang,
  bannerHeight,
}) => {
  const [activeSection, setActiveSection] = useState<SectionId>('directory');
  const t = UI_STRINGS[lang];
  const newsT = NEWS_STRINGS[lang];
  const labels = SHORT_MOBILE_LABELS[lang];

  useEffect(() => {
    const sectionIds: SectionId[] = ['directory', 'updates', 'journeys', 'comparison', 'faq'];
    const handleScroll = () => {
      const scrollY = window.scrollY + 180;
      let current: SectionId = 'directory';
      for (const id of sectionIds) {
        const el = document.getElementById(id);
        if (el && el.offsetTop <= scrollY) {
          current = id;
        }
      }
      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: Array<{
    id: SectionId;
    label: string;
    fullLabel: string;
    Icon: React.FC<{ className?: string }>;
  }> = [
    { id: 'directory', label: labels.directory, fullLabel: t.navDirectory, Icon: LayoutGrid },
    { id: 'updates', label: labels.updates, fullLabel: newsT.navLabel, Icon: Newspaper },
    { id: 'journeys', label: labels.journeys, fullLabel: t.navJourneys, Icon: GitBranch },
    { id: 'comparison', label: labels.comparison, fullLabel: t.navComparison, Icon: Table2 },
    { id: 'faq', label: labels.faq, fullLabel: t.navFaq, Icon: HelpCircle },
  ];

  const handleNavigate = (id: SectionId) => {
    setActiveSection(id);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <nav
      aria-label={t.brandTitle}
      style={{ bottom: `${bannerHeight}px` }}
      className="md:hidden fixed inset-x-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-[0_-4px_16px_rgba(15,23,42,0.06)] dark:shadow-[0_-4px_16px_rgba(0,0,0,0.35)]"
    >
      <div className="grid grid-cols-5 h-16 max-w-[600px] mx-auto px-1">
        {navItems.map(({ id, label, fullLabel, Icon }) => {
          const isActive = activeSection === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => handleNavigate(id)}
              aria-label={fullLabel}
              aria-current={isActive ? 'page' : undefined}
              className={`flex flex-col items-center justify-center gap-1 py-1.5 rounded-lg transition-colors cursor-pointer active:scale-95 ${
                isActive
                  ? 'text-[#0F6E4A] dark:text-emerald-400'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <span
                className={`flex items-center justify-center w-9 h-6 rounded-full transition-colors ${
                  isActive ? 'bg-[#0F6E4A]/12 dark:bg-emerald-500/20' : ''
                }`}
              >
                <Icon className="w-4 h-4" aria-hidden="true" />
              </span>
              <span className="text-[11px] font-semibold leading-none whitespace-nowrap">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
