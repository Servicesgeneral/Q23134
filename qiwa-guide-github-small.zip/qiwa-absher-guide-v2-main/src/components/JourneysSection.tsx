import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { LanguageCode, ServiceItem } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS, USER_JOURNEYS } from '../data/platformsAndJourneys';
import { SERVICES } from '../data/servicesPart2';

interface JourneysSectionProps {
  lang: LanguageCode;
  dir: 'rtl' | 'ltr';
  onOpenService: (service: ServiceItem) => void;
}

export const JourneysSection: React.FC<JourneysSectionProps> = ({
  lang,
  dir,
  onOpenService,
}) => {
  const [activeJourneyId, setActiveJourneyId] = useState(USER_JOURNEYS[0].id);
  const t = UI_STRINGS[lang];
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;
  const ArrowIcon = dir === 'rtl' ? ArrowLeft : ArrowRight;

  const activeJourney =
    USER_JOURNEYS.find((j) => j.id === activeJourneyId) || USER_JOURNEYS[0];

  const handleOpenRelated = (serviceId?: string) => {
    if (!serviceId) return;
    const found = SERVICES.find((s) => s.id === serviceId);
    if (found) onOpenService(found);
  };

  return (
    <section
      id="journeys"
      className="py-12 lg:py-16 bg-white dark:bg-slate-900 border-y border-slate-200 dark:border-slate-800 overflow-x-clip"
    >
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        <div className="mb-8 max-w-2xl">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
            {t.journeysKicker}
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-50 mb-3">
            {t.journeysTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.journeysSubtitle}
          </p>
        </div>

        {/* Journey Selector Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
          {USER_JOURNEYS.map((journey, index) => {
            const isSelected = journey.id === activeJourney.id;
            return (
              <button
                key={journey.id}
                type="button"
                onClick={() => setActiveJourneyId(journey.id)}
                className={`text-start p-4 rounded-xl border transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                  isSelected
                    ? 'bg-[#0F6E4A] border-[#0F6E4A] text-white'
                    : 'bg-[#F8FAFC] dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <span
                    className={`font-mono text-xs tabular-nums ${
                      isSelected ? 'text-white/80' : 'text-slate-400 dark:text-slate-500'
                    }`}
                  >
                    0{index + 1}
                  </span>
                  <span
                    className={`text-xs tabular-nums ${
                      isSelected ? 'text-white/85' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {journey.stages.length} {t.stagesCountSuffix}
                  </span>
                </div>
                <p className="font-display text-sm font-semibold leading-snug">
                  {journey.title[lang]}
                </p>
              </button>
            );
          })}
        </div>

        {/* Active Journey Stages */}
        <div className="border border-slate-200 dark:border-slate-800 rounded-xl bg-[#F8FAFC] dark:bg-slate-950 p-6 sm:p-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800 mb-6">
            <div>
              <h3 className="font-display text-xl font-bold text-slate-900 dark:text-slate-100 mb-1.5">
                {activeJourney.title[lang]}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-2xl">
                {activeJourney.summary[lang]}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 dark:text-slate-400 shrink-0 tabular-nums">
              <span>
                {t.journeyAudiencePrefix} {activeJourney.audience[lang]}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {t.journeyTimePrefix} {activeJourney.estimatedTotalTime[lang]}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {activeJourney.stages.map((stage, idx) => {
              const platform = PLATFORMS[stage.platform];
              const isLast = idx === activeJourney.stages.length - 1;

              return (
                <div
                  key={stage.stepNumber}
                  className="relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="font-mono text-xs font-medium text-slate-400 dark:text-slate-500 tabular-nums">
                        {t.stagePrefix} {stage.stepNumber}
                      </span>
                      <span className={`text-xs font-semibold ${platform.accentText}`}>
                        {platform.name[lang]}
                      </span>
                    </div>

                    <h4 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-2 leading-snug">
                      {stage.title[lang]}
                    </h4>

                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                      {stage.action[lang]}
                    </p>
                  </div>

                  {stage.relatedServiceId && (
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => handleOpenRelated(stage.relatedServiceId)}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:text-[#0B563A] dark:hover:text-emerald-300 cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:underline"
                      >
                        <span>{t.serviceDetailsLink}</span>
                        <ChevronIcon className="w-3.5 h-3.5" aria-hidden="true" />
                      </button>
                      {!isLast && (
                        <ArrowIcon
                          className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600 hidden lg:block"
                          aria-hidden="true"
                        />
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
