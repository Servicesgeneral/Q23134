import React, { useState } from 'react';
import {
  ArrowDownLeft,
  ArrowDownRight,
  Briefcase,
  Building2,
  Fingerprint,
  Globe,
  Moon,
  Search,
  Shield,
  ShieldCheck,
  Sun,
} from 'lucide-react';
import heroArchitectureImg from '../assets/images/riyadh_digital_architecture_1794749217872.jpg';
import { LanguageCode, PlatformId } from '../types/guide';
import { LANGUAGES, UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

interface HeroSectionProps {
  lang: LanguageCode;
  dir: 'rtl' | 'ltr';
  onChangeLang: (lang: LanguageCode) => void;
  isDark: boolean;
  onToggleDark: () => void;
  totalServices: number;
  onSelectPlatformAndScroll: (platform: PlatformId) => void;
  onFocusSearch: () => void;
  onOpenCompliance: () => void;
}

const PLATFORM_TOP_ACCENT: Record<PlatformId, string> = {
  qiwa: 'border-t-2 border-t-[#0F6E4A] dark:border-t-emerald-500',
  absher: 'border-t-2 border-t-[#1D4ED8] dark:border-t-blue-500',
  nafath: 'border-t-2 border-t-[#4338CA] dark:border-t-indigo-500',
};

const PLATFORM_ICON_BG: Record<PlatformId, string> = {
  qiwa: 'bg-[#0F6E4A]/10 text-[#0F6E4A] dark:bg-emerald-500/15 dark:text-emerald-400',
  absher: 'bg-[#1D4ED8]/10 text-[#1D4ED8] dark:bg-blue-500/15 dark:text-blue-400',
  nafath: 'bg-[#4338CA]/10 text-[#4338CA] dark:bg-indigo-500/15 dark:text-indigo-400',
};

function renderPlatformIcon(pid: PlatformId) {
  if (pid === 'qiwa') return <Briefcase className="w-4 h-4 shrink-0" aria-hidden="true" />;
  if (pid === 'absher') return <Shield className="w-4 h-4 shrink-0" aria-hidden="true" />;
  return <Fingerprint className="w-4 h-4 shrink-0" aria-hidden="true" />;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  lang,
  dir,
  onChangeLang,
  isDark,
  onToggleDark,
  totalServices,
  onSelectPlatformAndScroll,
  onFocusSearch,
  onOpenCompliance,
}) => {
  const [imgError, setImgError] = useState(false);
  const t = UI_STRINGS[lang];
  const ArrowIcon = dir === 'rtl' ? ArrowDownLeft : ArrowDownRight;

  return (
    <section
      id="top"
      className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-x-clip"
    >
      {/* Workspace Utility & Compliance Strip */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-slate-950">
        <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-2.5">
          {/* Language Switcher */}
          <div className="flex items-center gap-1.5 min-w-0 max-w-full overflow-x-auto">
            <Globe className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" aria-hidden="true" />
            <div
              role="group"
              aria-label={t.languageLabel}
              className="inline-flex items-center gap-0.5 p-0.5 bg-slate-200/70 dark:bg-slate-800 rounded-lg"
            >
              {LANGUAGES.map((item) => {
                const isActive = item.code === lang;
                return (
                  <button
                    key={item.code}
                    type="button"
                    onClick={() => onChangeLang(item.code)}
                    className={`px-2 sm:px-2.5 py-1 text-[11px] sm:text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                      isActive
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {item.nativeLabel}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Compliance Quick Link & Dark Mode Switch */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onOpenCompliance}
              aria-label={t.viewComplianceBtn}
              className="inline-flex items-center gap-1 text-[11px] sm:text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-[#0F6E4A] dark:hover:text-emerald-400 transition-colors cursor-pointer whitespace-nowrap shrink-0 py-1 px-2 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#0F6E4A] dark:text-emerald-400 shrink-0" aria-hidden="true" />
              <span className="hidden sm:inline">{t.viewComplianceBtn}</span>
            </button>

            <button
              type="button"
              onClick={onToggleDark}
              aria-label={isDark ? t.lightModeLabel : t.darkModeLabel}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[11px] sm:text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
            >
              {isDark ? (
                <>
                  <Sun className="w-3.5 h-3.5 text-amber-400 shrink-0" aria-hidden="true" />
                  <span>{t.lightModeLabel}</span>
                </>
              ) : (
                <>
                  <Moon className="w-3.5 h-3.5 text-slate-600 shrink-0" aria-hidden="true" />
                  <span>{t.darkModeLabel}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 pt-5 pb-8 sm:pt-8 sm:pb-12 lg:pt-10 lg:pb-16">
        {/* Prominent Google Play & Saudi Policy Non-Affiliation Disclaimer Bar */}
        <div className="mb-5 sm:mb-7 px-3.5 py-2.5 sm:px-4 sm:py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-slate-950 flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-3">
          <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            <strong className="font-semibold text-slate-900 dark:text-slate-100">
              {t.disclaimerBannerPrefix}{' '}
            </strong>
            {t.disclaimerBannerText}
          </p>
          <button
            type="button"
            onClick={onOpenCompliance}
            className="text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0 self-start sm:self-center cursor-pointer"
          >
            {t.viewComplianceBtn}
          </button>
        </div>

        {/* Mobile Showcase Architectural Visual Banner (Visible immediately on first phone screen) */}
        <div className="lg:hidden mb-6 relative h-44 sm:h-52 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-900 shadow-sm">
          {!imgError ? (
            <img
              src={heroArchitectureImg}
              alt={t.heroImageAlt}
              onError={() => setImgError(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#0F6E4A] to-slate-900 flex items-center justify-center">
              <Building2 className="w-12 h-12 text-white/80" aria-hidden="true" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-slate-950/15" />
          <div className="absolute inset-x-0 bottom-0 p-4 text-white">
            <p className="text-[11px] font-medium text-emerald-300 mb-1">
              {t.heroKicker}
            </p>
            <div className="flex items-end justify-between gap-3">
              <p className="font-display text-base sm:text-lg font-bold leading-snug">
                {t.brandTitle}
              </p>
              <span className="font-mono text-xs text-white/90 tabular-nums shrink-0">
                {totalServices} {t.statServicesUnit}
              </span>
            </div>
          </div>
        </div>

        {/* 2-Column Institutional Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between py-1 min-w-0">
            <div>
              <p className="hidden lg:block text-xs font-medium text-slate-500 dark:text-slate-400 tracking-wide mb-4">
                {t.heroKicker}
              </p>

              <h1
                className="font-display text-2xl sm:text-4xl lg:text-[2.65rem] font-bold text-slate-900 dark:text-slate-50 leading-[1.28] tracking-tight mb-3.5 sm:mb-5 max-w-2xl"
                style={{ textWrap: 'balance' }}
              >
                {t.heroTitle}
              </h1>

              <p className="text-sm sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl mb-6 sm:mb-8">
                {t.heroSubtitle}
              </p>

              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3 mb-7 sm:mb-8">
                <button
                  type="button"
                  onClick={onFocusSearch}
                  className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 text-sm font-semibold text-white bg-[#0F6E4A] hover:bg-[#0B563A] active:scale-[0.98] rounded-xl transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#0F6E4A]"
                >
                  <Search className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.heroSearchCta}</span>
                </button>

                <a
                  href="#journeys"
                  className="inline-flex items-center gap-2 px-4 sm:px-5 py-2.5 text-sm font-semibold text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200/80 dark:hover:bg-slate-700 active:scale-[0.98] rounded-xl transition-all duration-150 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-400"
                >
                  <span>{t.heroJourneysCta}</span>
                  <ArrowIcon className="w-4 h-4 shrink-0" aria-hidden="true" />
                </a>
              </div>
            </div>

            {/* Platform Quick Access Strip */}
            <div className="pt-5 sm:pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
              {(['qiwa', 'absher', 'nafath'] as PlatformId[]).map((pid) => {
                const platform = PLATFORMS[pid];
                return (
                  <button
                    key={pid}
                    type="button"
                    onClick={() => onSelectPlatformAndScroll(pid)}
                    className={`group text-start p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 ${PLATFORM_TOP_ACCENT[pid]} hover:border-slate-300 dark:hover:border-slate-700 bg-[#F8FAFC] dark:bg-slate-950 hover:bg-white dark:hover:bg-slate-800/70 active:scale-[0.98] transition-all duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span
                          className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${PLATFORM_ICON_BG[pid]}`}
                        >
                          {renderPlatformIcon(pid)}
                        </span>
                        <span className={`font-display text-sm font-bold ${platform.accentText} truncate`}>
                          {platform.name[lang]}
                        </span>
                      </div>
                      <span className="font-mono text-[11px] text-slate-400 dark:text-slate-500 shrink-0" dir="ltr">
                        {platform.domainLabel}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                      {platform.tagline[lang]}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Desktop Visual Frame */}
          <div className="hidden lg:flex lg:col-span-5 flex-col min-w-0">
            <div className="relative flex-1 min-h-[260px] lg:min-h-0 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800">
              {!imgError ? (
                <img
                  src={heroArchitectureImg}
                  alt={t.heroImageAlt}
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full min-h-[280px] flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-900">
                  <Building2 className="w-12 h-12 text-[#0F6E4A] dark:text-emerald-400 mb-3" aria-hidden="true" />
                  <p className="font-display text-base font-semibold text-slate-800 dark:text-slate-100">
                    {t.brandTitle}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    {t.statPlatformsSub}
                  </p>
                </div>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2.5">
              {t.heroCaption}
            </p>
          </div>
        </div>

        {/* Full-Width 4-Column Institutional Summary Strip */}
        <div className="mt-8 sm:mt-10 pt-6 sm:pt-8 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-3 sm:p-0 rounded-xl bg-[#F8FAFC] sm:bg-transparent dark:bg-slate-950 sm:dark:bg-transparent border border-slate-200/80 sm:border-0 dark:border-slate-800">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">{t.statPlatformsLabel}</p>
            <p className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
              {t.statPlatformsValue}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{t.statPlatformsSub}</p>
          </div>
          <div className="p-3 sm:p-0 rounded-xl bg-[#F8FAFC] sm:bg-transparent dark:bg-slate-950 sm:dark:bg-transparent border border-slate-200/80 sm:border-0 dark:border-slate-800">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">{t.statServicesLabel}</p>
            <p className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
              {totalServices} {t.statServicesUnit}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{t.statServicesSub}</p>
          </div>
          <div className="p-3 sm:p-0 rounded-xl bg-[#F8FAFC] sm:bg-transparent dark:bg-slate-950 sm:dark:bg-transparent border border-slate-200/80 sm:border-0 dark:border-slate-800">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">{t.statJourneysLabel}</p>
            <p className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
              {t.statJourneysValue}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{t.statJourneysSub}</p>
          </div>
          <div className="p-3 sm:p-0 rounded-xl bg-[#F8FAFC] sm:bg-transparent dark:bg-slate-950 sm:dark:bg-transparent border border-slate-200/80 sm:border-0 dark:border-slate-800">
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-1">{t.statChecklistLabel}</p>
            <p className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-slate-100 tabular-nums">
              {t.statChecklistValue}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">{t.statChecklistSub}</p>
          </div>
        </div>
      </div>
    </section>
  );
};
