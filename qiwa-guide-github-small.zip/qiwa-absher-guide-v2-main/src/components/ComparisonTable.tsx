import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { LanguageCode, ServiceItem } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';
import { SERVICES } from '../data/servicesPart2';

interface ComparisonTableProps {
  lang: LanguageCode;
  dir: 'rtl' | 'ltr';
  onOpenService: (service: ServiceItem) => void;
}

const FEATURED_ROW_IDS = [
  'nafath-activation',
  'qiwa-contract-auth',
  'qiwa-employee-transfer',
  'qiwa-work-permit',
  'absher-iqama-renew',
  'absher-exit-reentry',
  'absher-passport',
  'absher-national-id',
  'qiwa-change-occupation',
];

export const ComparisonTable: React.FC<ComparisonTableProps> = ({
  lang,
  dir,
  onOpenService,
}) => {
  const t = UI_STRINGS[lang];
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;
  const rows = SERVICES.filter((s) => FEATURED_ROW_IDS.includes(s.id));

  return (
    <section id="comparison" className="py-12 lg:py-16 overflow-x-clip">
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        <div className="mb-8 max-w-2xl">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
            {t.compKicker}
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-50 mb-3">
            {t.compTitle}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            {t.compSubtitle}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden max-w-full min-w-0">
          <div className="overflow-x-auto max-w-full" style={{ touchAction: 'pan-x pan-y' }}>
            <table className="w-full text-start border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-slate-950 text-xs font-semibold text-slate-600 dark:text-slate-400">
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colCode}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colService}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colPlatform}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colAudience}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colDuration}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colFee}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    {t.colNafath}
                  </th>
                  <th scope="col" className="py-3.5 px-4 text-start whitespace-nowrap">
                    <span className="sr-only">{t.colAction}</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {rows.map((service) => {
                  const platform = PLATFORMS[service.platform];
                  return (
                    <tr
                      key={service.id}
                      className="hover:bg-[#F8FAFC] dark:hover:bg-slate-800/50 transition-colors duration-100"
                    >
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-400 dark:text-slate-500 tabular-nums whitespace-nowrap">
                        {service.code}
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-900 dark:text-slate-100 min-w-[220px]">
                        <button
                          type="button"
                          onClick={() => onOpenService(service)}
                          className="text-start hover:text-[#0F6E4A] dark:hover:text-emerald-400 transition-colors cursor-pointer focus-visible:outline-none focus-visible:underline"
                        >
                          {service.title[lang]}
                        </button>
                      </td>
                      <td className={`py-3.5 px-4 font-semibold whitespace-nowrap ${platform.accentText}`}>
                        {platform.shortName[lang]}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {t.audienceOptions[service.audience]}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 tabular-nums whitespace-nowrap">
                        {service.duration[lang]}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-200 tabular-nums min-w-[180px]">
                        {service.fee[lang]}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                        {service.requiresNafath ? t.nafathYes : t.nafathNo}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => onOpenService(service)}
                          aria-label={`${t.viewLabel} ${service.title[lang]}`}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:text-[#0B563A] dark:hover:text-emerald-300 cursor-pointer py-1 px-2 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
                        >
                          <span>{t.viewLabel}</span>
                          <ChevronIcon className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};
