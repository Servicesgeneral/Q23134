import React from 'react';
import { ExternalLink, ShieldCheck } from 'lucide-react';
import { LanguageCode, PlatformId } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

interface FooterProps {
  lang: LanguageCode;
  onOpenCompliance: () => void;
}

export const Footer: React.FC<FooterProps> = ({ lang, onOpenCompliance }) => {
  const t = UI_STRINGS[lang];

  return (
    <footer className="bg-[#F8FAFC] dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 py-10 overflow-x-clip">
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-8 border-b border-slate-200 dark:border-slate-800">
          <div className="md:col-span-5">
            <p className="font-display text-base font-bold text-slate-900 dark:text-slate-100 mb-2">
              {t.brandTitle}
            </p>
            <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed max-w-md mb-4">
              {t.footerSummary}
            </p>
            <button
              type="button"
              onClick={onOpenCompliance}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 rounded-lg transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4 text-[#0F6E4A] dark:text-emerald-400 shrink-0" aria-hidden="true" />
              <span>{t.footerLegalBtn}</span>
            </button>
          </div>

          <div className="md:col-span-7">
            <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3">
              {t.footerOfficialLinksTitle}
            </p>
            <ul className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(['qiwa', 'absher', 'nafath'] as PlatformId[]).map((pid) => {
                const platform = PLATFORMS[pid];
                return (
                  <li key={pid}>
                    <a
                      href={platform.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-lg text-sm font-medium text-slate-800 dark:text-slate-200 transition-colors"
                    >
                      <div>
                        <span className="block">{platform.name[lang]}</span>
                        <span className="font-mono text-[11px] text-slate-400 dark:text-slate-500" dir="ltr">
                          {platform.domainLabel}
                        </span>
                      </div>
                      <ExternalLink
                        className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0"
                        aria-hidden="true"
                      />
                    </a>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
          <p>{t.footerNotice}</p>
          <p className="tabular-nums">{t.brandTitle}</p>
        </div>
      </div>
    </footer>
  );
};
