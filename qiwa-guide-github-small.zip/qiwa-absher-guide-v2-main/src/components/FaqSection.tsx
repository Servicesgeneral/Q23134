import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { LanguageCode } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { FAQ_ITEMS, PLATFORMS } from '../data/platformsAndJourneys';

interface FaqSectionProps {
  lang: LanguageCode;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ lang }) => {
  const [openId, setOpenId] = useState<string | null>(FAQ_ITEMS[0].id);
  const t = UI_STRINGS[lang];

  const toggle = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <section
      id="faq"
      className="py-12 lg:py-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 overflow-x-clip"
    >
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-4">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {t.faqKicker}
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-50 mb-3">
              {t.faqTitle}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {t.faqSubtitle}
            </p>
          </div>

          <div className="lg:col-span-8 divide-y divide-slate-200 dark:divide-slate-800 border-t border-b border-slate-200 dark:border-slate-800">
            {FAQ_ITEMS.map((item) => {
              const isOpen = openId === item.id;
              return (
                <div key={item.id} className="py-5">
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => toggle(item.id)}
                    className="w-full flex items-start justify-between gap-4 text-start cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
                  >
                    <div>
                      <span className="block font-display text-base font-semibold text-slate-900 dark:text-slate-100 leading-snug">
                        {item.question[lang]}
                      </span>
                      <span className="inline-block mt-1.5 text-xs text-slate-500 dark:text-slate-400">
                        {item.platforms.map((pid) => PLATFORMS[pid].name[lang]).join(' · ')}
                      </span>
                    </div>
                    <ChevronDown
                      className={`w-5 h-5 text-slate-400 dark:text-slate-500 shrink-0 mt-0.5 transition-transform duration-150 ${
                        isOpen ? 'rotate-180 text-slate-700 dark:text-slate-200' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>

                  {isOpen && (
                    <div className="mt-3 pe-8 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                      {item.answer[lang]}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
