import React, { useEffect } from 'react';
import { ChevronLeft, ChevronRight, Trash2, X } from 'lucide-react';
import { LanguageCode, ServiceItem } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

interface SavedServicesDrawerProps {
  lang: LanguageCode;
  dir: 'rtl' | 'ltr';
  isOpen: boolean;
  onClose: () => void;
  savedServices: ServiceItem[];
  onRemoveSaved: (id: string) => void;
  onOpenService: (service: ServiceItem) => void;
  checkedRequirements: Record<string, boolean[]>;
}

export const SavedServicesDrawer: React.FC<SavedServicesDrawerProps> = ({
  lang,
  dir,
  isOpen,
  onClose,
  savedServices,
  onRemoveSaved,
  onOpenService,
  checkedRequirements,
}) => {
  const t = UI_STRINGS[lang];
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="saved-drawer-title"
    >
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-[1px]"
        aria-hidden="true"
      />

      <div className="relative z-10 w-full max-w-md bg-white dark:bg-slate-900 h-full overflow-y-auto border-s border-slate-200 dark:border-slate-800 flex flex-col justify-between">
        <div>
          <div className="sticky top-0 z-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between">
            <div>
              <h2
                id="saved-drawer-title"
                className="font-display text-lg font-bold text-slate-900 dark:text-slate-100"
              >
                {t.savedTitle}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                {savedServices.length} {t.savedCountSuffix}
              </p>
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label={t.closeBtn}
              className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>

          <div className="p-6">
            {savedServices.length === 0 ? (
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl bg-[#F8FAFC] dark:bg-slate-950 p-8 text-center">
                <p className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-2">
                  {t.savedEmptyTitle}
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-5">
                  {t.savedEmptyDesc}
                </p>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-sm font-medium text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  {t.savedEmptyCta}
                </button>
              </div>
            ) : (
              <ul className="space-y-3">
                {savedServices.map((service) => {
                  const platform = PLATFORMS[service.platform];
                  const checks = checkedRequirements[service.id] || [];
                  const completed = checks.filter(Boolean).length;
                  const total = service.requirements[lang].length;

                  return (
                    <li
                      key={service.id}
                      className="border border-slate-200 dark:border-slate-800 rounded-xl p-4 bg-white dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <span className={`text-xs font-semibold ${platform.accentText}`}>
                          {platform.name[lang]} ·{' '}
                          <span className="font-mono text-slate-400 dark:text-slate-500">
                            {service.code}
                          </span>
                        </span>
                        <button
                          type="button"
                          onClick={() => onRemoveSaved(service.id)}
                          aria-label={t.removeSavedAria}
                          className="p-1 text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 rounded transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </div>

                      <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3 leading-snug">
                        {service.title[lang]}
                      </h3>

                      <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                        <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                          {t.savedReadinessPrefix} {completed}/{total}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onOpenService(service);
                          }}
                          className="inline-flex items-center gap-1 text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:text-[#0B563A] dark:hover:text-emerald-300 cursor-pointer whitespace-nowrap"
                        >
                          <span>{t.openDetailsBtn}</span>
                          <ChevronIcon className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
