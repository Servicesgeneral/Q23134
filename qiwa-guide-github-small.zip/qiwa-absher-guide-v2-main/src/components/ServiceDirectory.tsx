import React from 'react';
import {
  Bookmark,
  BookmarkCheck,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Search,
  X,
} from 'lucide-react';
import { AudienceKey, LanguageCode, PlatformId, ServiceItem } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

const CARD_PLATFORM_ACCENT: Record<PlatformId, string> = {
  qiwa: 'border-t-2 border-t-[#0F6E4A] dark:border-t-emerald-500',
  absher: 'border-t-2 border-t-[#1D4ED8] dark:border-t-blue-500',
  nafath: 'border-t-2 border-t-[#4338CA] dark:border-t-indigo-500',
};

interface ServiceDirectoryProps {
  lang: LanguageCode;
  dir: 'rtl' | 'ltr';
  services: ServiceItem[];
  selectedPlatform: PlatformId | 'all';
  onPlatformChange: (platform: PlatformId | 'all') => void;
  selectedAudience: AudienceKey;
  onAudienceChange: (audience: AudienceKey) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  searchInputRef: React.RefObject<HTMLInputElement | null>;
  savedIds: string[];
  onToggleSave: (id: string) => void;
  onOpenService: (service: ServiceItem) => void;
  checkedRequirements: Record<string, boolean[]>;
}

const AUDIENCE_KEYS: AudienceKey[] = ['all', 'individuals', 'establishments', 'residents'];

export const ServiceDirectory: React.FC<ServiceDirectoryProps> = ({
  lang,
  dir,
  services,
  selectedPlatform,
  onPlatformChange,
  selectedAudience,
  onAudienceChange,
  searchQuery,
  onSearchChange,
  searchInputRef,
  savedIds,
  onToggleSave,
  onOpenService,
  checkedRequirements,
}) => {
  const t = UI_STRINGS[lang];
  const ChevronIcon = dir === 'rtl' ? ChevronLeft : ChevronRight;

  const platformTabs: Array<{ id: PlatformId | 'all'; label: string }> = [
    { id: 'all', label: t.tabAllPlatforms },
    { id: 'qiwa', label: PLATFORMS.qiwa.name[lang] },
    { id: 'absher', label: PLATFORMS.absher.name[lang] },
    { id: 'nafath', label: PLATFORMS.nafath.name[lang] },
  ];

  const hasActiveFilters =
    selectedPlatform !== 'all' || selectedAudience !== 'all' || searchQuery.trim().length > 0;

  const resetFilters = () => {
    onPlatformChange('all');
    onAudienceChange('all');
    onSearchChange('');
  };

  return (
    <section id="directory" className="py-10 sm:py-12 lg:py-16 overflow-x-clip">
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {t.dirKicker}
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-50">
              {t.dirTitle}
            </h2>
          </div>
          <p className="text-sm text-slate-600 dark:text-slate-400 tabular-nums">
            {t.dirShowingPrefix}{' '}
            <span className="font-semibold text-slate-900 dark:text-slate-100">{services.length}</span>{' '}
            {t.dirShowingSuffix}
          </p>
        </div>

        {/* Filter & Search Toolbar */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 mb-8 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            {/* Platform Segmented Tabs */}
            <div
              role="tablist"
              aria-label={t.dirTitle}
              className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg self-start max-w-full"
            >
              {platformTabs.map((tab) => {
                const isActive = selectedPlatform === tab.id;
                return (
                  <button
                    key={tab.id}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => onPlatformChange(tab.id)}
                    className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                      isActive
                        ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                        : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Search Input */}
            <div className="relative flex-1 lg:max-w-sm">
              <Search
                className="w-4 h-4 text-slate-400 dark:text-slate-500 absolute start-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                ref={searchInputRef}
                type="search"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={t.searchPlaceholder}
                aria-label={t.searchAriaLabel}
                className="w-full ps-10 pe-9 py-2 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:bg-white dark:focus:bg-slate-900 focus:border-[#0F6E4A] focus:ring-2 focus:ring-[#0F6E4A]/15 transition-colors"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  aria-label={t.clearSearchAria}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" aria-hidden="true" />
                </button>
              )}
            </div>
          </div>

          {/* Audience Secondary Filter */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-500 dark:text-slate-400 me-1">
                {t.audienceLabel}
              </span>
              {AUDIENCE_KEYS.map((audKey) => {
                const isActive = selectedAudience === audKey;
                return (
                  <button
                    key={audKey}
                    type="button"
                    onClick={() => onAudienceChange(audKey)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                      isActive
                        ? 'bg-slate-900 dark:bg-emerald-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {t.audienceOptions[audKey]}
                  </button>
                );
              })}
            </div>

            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0 cursor-pointer py-1 px-2 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
              >
                <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.resetFiltersBtn}</span>
              </button>
            )}
          </div>
        </div>

        {/* Services Grid */}
        {services.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center">
            <p className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100 mb-2">
              {t.emptyTitle}
            </p>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-md mx-auto mb-6">
              {t.emptyDesc}
            </p>
            <button
              type="button"
              onClick={resetFilters}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-4 h-4" aria-hidden="true" />
              <span>{t.emptyCta}</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((service) => {
              const platform = PLATFORMS[service.platform];
              const isSaved = savedIds.includes(service.id);
              const checks = checkedRequirements[service.id] || [];
              const completedChecks = checks.filter(Boolean).length;
              const reqCount = service.requirements[lang].length;

              return (
                <article
                  key={service.id}
                  className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 ${CARD_PLATFORM_ACCENT[service.platform]} rounded-xl p-5 flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-sm transition-all duration-150`}
                >
                  <div>
                    {/* Quiet unboxed kicker + bookmark action */}
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 min-w-0">
                        <span className={`font-semibold ${platform.accentText} whitespace-nowrap`}>
                          {platform.name[lang]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">{service.category[lang]}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums text-slate-400 dark:text-slate-500">
                          {service.code}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onToggleSave(service.id)}
                        aria-label={isSaved ? t.unsaveServiceAria : t.saveServiceAria}
                        className={`p-1.5 rounded-md transition-colors cursor-pointer shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                          isSaved
                            ? 'text-[#0F6E4A] dark:text-emerald-400 bg-[#0F6E4A]/10 dark:bg-emerald-500/15'
                            : 'text-slate-400 dark:text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {isSaved ? (
                          <BookmarkCheck className="w-4 h-4" aria-hidden="true" />
                        ) : (
                          <Bookmark className="w-4 h-4" aria-hidden="true" />
                        )}
                      </button>
                    </div>

                    {/* Title & Summary */}
                    <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-slate-100 leading-snug mb-2">
                      <button
                        type="button"
                        onClick={() => onOpenService(service)}
                        className="text-start hover:text-[#0F6E4A] dark:hover:text-emerald-400 transition-colors cursor-pointer focus-visible:outline-none focus-visible:underline"
                      >
                        {service.title[lang]}
                      </button>
                    </h3>

                    <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-5 line-clamp-3">
                      {service.summary[lang]}
                    </p>
                  </div>

                  {/* Unboxed Metadata + Action Footer */}
                  <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                      <span>
                        {t.cardAudiencePrefix} {t.audienceOptions[service.audience]}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {t.cardDurationPrefix} {service.duration[lang]}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {service.requiresNafath ? t.cardNafathRequired : t.cardDirectAccess}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onOpenService(service)}
                        className="inline-flex items-center gap-1 text-sm font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:text-[#0B563A] dark:hover:text-emerald-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
                      >
                        <span>{t.cardActionLabel}</span>
                        <ChevronIcon className="w-4 h-4" aria-hidden="true" />
                      </button>

                      {completedChecks > 0 ? (
                        <span className="text-xs font-medium text-[#0F6E4A] dark:text-emerald-400 tabular-nums">
                          {t.cardReadyPrefix} {completedChecks}/{reqCount}
                        </span>
                      ) : (
                        <span className="text-xs text-slate-400 dark:text-slate-500 tabular-nums">
                          {reqCount} {t.cardReqSuffix}
                        </span>
                      )}
                    </div>

                    {completedChecks > 0 && reqCount > 0 && (
                      <div className="h-1 w-full rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full bg-[#0F6E4A] dark:bg-emerald-500 transition-all duration-200"
                          style={{ width: `${Math.round((completedChecks / reqCount) * 100)}%` }}
                        />
                      </div>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
