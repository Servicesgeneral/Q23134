import React, { useEffect } from 'react';
import {
  Bookmark,
  BookmarkCheck,
  Check,
  ExternalLink,
  RotateCcw,
  X,
} from 'lucide-react';
import { LanguageCode, ServiceItem } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

interface ServiceDetailDrawerProps {
  lang: LanguageCode;
  service: ServiceItem | null;
  onClose: () => void;
  isSaved: boolean;
  onToggleSave: (id: string) => void;
  checkedState: boolean[];
  onToggleRequirement: (serviceId: string, index: number) => void;
  onResetRequirements: (serviceId: string) => void;
}

export const ServiceDetailDrawer: React.FC<ServiceDetailDrawerProps> = ({
  lang,
  service,
  onClose,
  isSaved,
  onToggleSave,
  checkedState,
  onToggleRequirement,
  onResetRequirements,
}) => {
  const t = UI_STRINGS[lang];

  useEffect(() => {
    if (!service) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [service, onClose]);

  if (!service) return null;

  const platform = PLATFORMS[service.platform];
  const reqList = service.requirements[lang];
  const stepList = service.steps[lang];
  const completedCount = checkedState.filter(Boolean).length;
  const totalReq = reqList.length;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      role="dialog"
      aria-modal="true"
      aria-labelledby="service-drawer-title"
    >
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-[1px] transition-opacity"
        aria-hidden="true"
      />

      {/* Drawer Panel */}
      <div className="relative z-10 w-full max-w-2xl bg-white dark:bg-slate-900 h-full overflow-y-auto border-s border-slate-200 dark:border-slate-800 flex flex-col justify-between">
        <div>
          {/* Sticky Drawer Header */}
          <div className="sticky top-0 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800 px-6 py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 min-w-0">
              <span className={`font-semibold ${platform.accentText} whitespace-nowrap`}>
                {platform.name[lang]}
              </span>
              <span aria-hidden="true">·</span>
              <span className="truncate">{service.category[lang]}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-slate-400 dark:text-slate-500">
                {service.code}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => onToggleSave(service.id)}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                  isSaved
                    ? 'bg-[#0F6E4A]/10 dark:bg-emerald-500/15 border-[#0F6E4A]/30 dark:border-emerald-500/40 text-[#0F6E4A] dark:text-emerald-400'
                    : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700'
                }`}
              >
                {isSaved ? (
                  <>
                    <BookmarkCheck className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{t.savedBadge}</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{t.saveBtn}</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={onClose}
                aria-label={t.closeDrawerAria}
                className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="p-6 sm:p-8 space-y-8">
            {/* Title & Description */}
            <div>
              <h2
                id="service-drawer-title"
                className="font-display text-2xl font-bold text-slate-900 dark:text-slate-50 leading-snug mb-3"
              >
                {service.title[lang]}
              </h2>
              <p className="text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                {service.summary[lang]}
              </p>
            </div>

            {/* Key Facts Grid */}
            <dl className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-5 border-y border-slate-200 dark:border-slate-800">
              <div>
                <dt className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                  {t.factAudience}
                </dt>
                <dd className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {t.audienceOptions[service.audience]}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                  {t.factDuration}
                </dt>
                <dd className="text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                  {service.duration[lang]}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                  {t.factNafath}
                </dt>
                <dd className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  {service.requiresNafath ? t.nafathYes : t.nafathNo}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500 dark:text-slate-400 mb-1">
                  {t.factFee}
                </dt>
                <dd className="text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
                  {service.fee[lang]}
                </dd>
              </div>
            </dl>

            {/* Interactive Requirements Checklist */}
            <div>
              <div className="flex items-center justify-between gap-4 mb-4">
                <div>
                  <h3 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100">
                    {t.reqHeading}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 tabular-nums">
                    {t.reqProgressPrefix} {completedCount} {t.reqProgressOf} {totalReq}
                  </p>
                </div>

                {completedCount > 0 && (
                  <button
                    type="button"
                    onClick={() => onResetRequirements(service.id)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer py-1 px-2 rounded focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
                  >
                    <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{t.reqResetBtn}</span>
                  </button>
                )}
              </div>

              <ul className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl bg-[#F8FAFC] dark:bg-slate-950">
                {reqList.map((req, idx) => {
                  const isChecked = Boolean(checkedState[idx]);
                  return (
                    <li key={idx}>
                      <button
                        type="button"
                        onClick={() => onToggleRequirement(service.id, idx)}
                        className="w-full flex items-start gap-3 p-3.5 text-start hover:bg-slate-100/70 dark:hover:bg-slate-800/60 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-[#0F6E4A]"
                      >
                        <span
                          className={`mt-0.5 w-5 h-5 rounded border flex items-center justify-center shrink-0 transition-colors ${
                            isChecked
                              ? 'bg-[#0F6E4A] border-[#0F6E4A] text-white'
                              : 'bg-white dark:bg-slate-900 border-slate-300 dark:border-slate-600 text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" aria-hidden="true" />
                        </span>
                        <span
                          className={`text-sm leading-relaxed ${
                            isChecked
                              ? 'text-slate-400 dark:text-slate-500 line-through'
                              : 'text-slate-700 dark:text-slate-200'
                          }`}
                        >
                          {req}
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Step-by-Step Execution */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
              <h3 className="font-display text-lg font-bold text-slate-900 dark:text-slate-100 mb-4 pt-4">
                {t.stepsHeading}
              </h3>

              <ol className="space-y-4">
                {stepList.map((step, idx) => (
                  <li key={idx} className="flex items-start gap-3.5">
                    <span className="font-mono text-xs font-semibold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 rounded-md w-7 h-7 flex items-center justify-center shrink-0 tabular-nums mt-0.5">
                      0{idx + 1}
                    </span>
                    <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed pt-0.5">
                      {step}
                    </p>
                  </li>
                ))}
              </ol>
            </div>

            {/* Notes & Cross-Platform Connections */}
            <div className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3">
              <h4 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
                {t.notesHeading}
              </h4>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {service.notes[lang]}
              </p>
              {service.connectedPlatforms.length > 0 && (
                <p className="text-xs text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-200 dark:border-slate-800">
                  {t.connectedPlatformsLabel}{' '}
                  <span className="font-semibold text-slate-700 dark:text-slate-200">
                    {service.connectedPlatforms.map((pid) => PLATFORMS[pid].name[lang]).join(' · ')}
                  </span>
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Sticky Footer */}
        <div className="sticky bottom-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-3">
          <a
            href={service.officialUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-4 sm:px-5 py-2.5 text-sm font-semibold text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors flex-1 sm:flex-initial text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#0F6E4A]"
          >
            <span>
              {t.goToOfficialPrefix} {platform.name[lang]} {t.goToOfficialSuffix}
            </span>
            <ExternalLink className="w-4 h-4 shrink-0" aria-hidden="true" />
          </a>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
