import React, { useEffect } from 'react';
import { ExternalLink, ShieldCheck, X } from 'lucide-react';
import { LanguageCode } from '../types/guide';
import { UI_STRINGS } from '../data/uiStrings';

interface ComplianceModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: LanguageCode;
}

export const ComplianceModal: React.FC<ComplianceModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const t = UI_STRINGS[lang];

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="compliance-modal-title"
    >
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-900/50 backdrop-blur-[1px]"
        aria-hidden="true"
      />

      <div className="relative z-10 w-full max-w-2xl max-h-[88vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2.5 min-w-0">
            <ShieldCheck
              className="w-5 h-5 text-[#0F6E4A] dark:text-emerald-400 shrink-0"
              aria-hidden="true"
            />
            <div className="min-w-0">
              <h2
                id="compliance-modal-title"
                className="font-display text-base sm:text-lg font-bold text-slate-900 dark:text-slate-100 truncate"
              >
                {t.complianceTitle}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {t.complianceSubtitle}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t.closeBtn}
            className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 space-y-7 overflow-y-auto">
          {/* 1. Disclaimer */}
          <section>
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 mb-2">
              {t.disclaimerSectionTitle}
            </h3>
            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed bg-[#F8FAFC] dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 rounded-lg p-4">
              {t.disclaimerFullText}
            </p>
          </section>

          {/* 2. Official Sources */}
          <section className="pt-5 border-t border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 mb-2">
              {t.sourcesSectionTitle}
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
              {t.sourcesDescription}
            </p>
            <ul className="space-y-2.5">
              {t.officialSourcesList.map((src) => (
                <li key={src.url}>
                  <a
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-between gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-[#F8FAFC] dark:bg-slate-800/60 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {src.name}
                      </p>
                      <p className="font-mono text-xs text-slate-500 dark:text-slate-400 mt-0.5" dir="ltr">
                        {src.org}
                      </p>
                    </div>
                    <ExternalLink
                      className="w-4 h-4 text-[#0F6E4A] dark:text-emerald-400 shrink-0"
                      aria-hidden="true"
                    />
                  </a>
                </li>
              ))}
            </ul>
          </section>

          {/* 3. Privacy Policy */}
          <section className="pt-5 border-t border-slate-200 dark:border-slate-800">
            <h3 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100 mb-3">
              {t.privacySectionTitle}
            </h3>
            <ul className="space-y-2.5">
              {t.privacyPoints.map((point, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-2.5 text-sm text-slate-600 dark:text-slate-300 leading-relaxed"
                >
                  <span className="font-mono text-xs text-slate-400 dark:text-slate-500 mt-1 shrink-0 tabular-nums">
                    0{idx + 1}.
                  </span>
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end bg-[#F8FAFC] dark:bg-slate-900">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            {t.closeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
