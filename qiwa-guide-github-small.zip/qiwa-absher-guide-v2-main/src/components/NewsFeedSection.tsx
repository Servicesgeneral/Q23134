import React, { useCallback, useEffect, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { ExternalLink, RefreshCw } from 'lucide-react';
import {
  GroundingSource,
  LanguageCode,
  NewsApiResponse,
  NewsUpdateItem,
  PlatformId,
} from '../types/guide';
import { AD_CONFIG } from '../config/admobRuntimeConfig';
import { NEWS_STRINGS } from '../data/newsStrings';
import { PLATFORMS } from '../data/platformsAndJourneys';

interface NewsFeedSectionProps {
  lang: LanguageCode;
}

export const NewsFeedSection: React.FC<NewsFeedSectionProps> = ({ lang }) => {
  const t = NEWS_STRINGS[lang];
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformId | 'all'>('all');
  const [items, setItems] = useState<NewsUpdateItem[]>([]);
  const [sources, setSources] = useState<GroundingSource[]>([]);
  const [fetchedAt, setFetchedAt] = useState<string | null>(null);
  const [isCached, setIsCached] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadNews = useCallback(
    async (platform: PlatformId | 'all', language: LanguageCode, forceRefresh = false) => {
      setIsLoading(true);
      setErrorMsg(null);

      try {
        const params = new URLSearchParams({
          platform,
          lang: language,
        });
        if (forceRefresh) params.set('refresh', '1');

        const apiBase =
          Capacitor.isNativePlatform() && AD_CONFIG.newsApiBaseUrl
            ? AD_CONFIG.newsApiBaseUrl.replace(/\/+$/, '')
            : '';
        const res = await fetch(`${apiBase}/api/news?${params.toString()}`);
        const payload = (await res.json()) as Partial<NewsApiResponse> & { error?: string };

        if (!res.ok) {
          throw new Error(payload.error || `HTTP ${res.status}`);
        }

        setItems(Array.isArray(payload.items) ? payload.items : []);
        setSources(Array.isArray(payload.sources) ? payload.sources : []);
        setFetchedAt(payload.fetchedAt || null);
        setIsCached(Boolean(payload.cached));
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Network error';
        setErrorMsg(message);
      } finally {
        setIsLoading(false);
      }
    },
    [],
  );

  useEffect(() => {
    void loadNews(selectedPlatform, lang, false);
  }, [selectedPlatform, lang, loadNews]);

  const platformTabs: Array<{ id: PlatformId | 'all'; label: string }> = [
    { id: 'all', label: t.allTab },
    { id: 'qiwa', label: PLATFORMS.qiwa.name[lang] },
    { id: 'absher', label: PLATFORMS.absher.name[lang] },
    { id: 'nafath', label: PLATFORMS.nafath.name[lang] },
  ];

  const formattedTime = fetchedAt
    ? new Date(fetchedAt).toLocaleTimeString(
        lang === 'ar' ? 'ar-SA' : lang === 'ur' ? 'ur-PK' : lang === 'bn' ? 'bn-BD' : 'en-US',
        { hour: '2-digit', minute: '2-digit' },
      )
    : null;

  return (
    <section
      id="updates"
      className="py-12 lg:py-16 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 overflow-x-clip"
    >
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 min-w-0">
        {/* Header Row */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-8">
          <div className="max-w-2xl">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">
              {t.kicker}
            </p>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 dark:text-slate-50 mb-2">
              {t.title}
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              {t.subtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            {formattedTime && !isLoading && !errorMsg && (
              <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                {t.lastUpdatedLabel} {formattedTime} · {isCached ? t.cachedLabel : t.liveLabel}
              </span>
            )}
            <button
              type="button"
              disabled={isLoading}
              onClick={() => void loadNews(selectedPlatform, lang, true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-100 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A]"
            >
              <RefreshCw
                className={`w-4 h-4 shrink-0 ${isLoading ? 'animate-spin' : ''}`}
                aria-hidden="true"
              />
              <span>{isLoading ? t.refreshingLabel : t.refreshBtn}</span>
            </button>
          </div>
        </div>

        {/* Platform Filter Tabs */}
        <div className="mb-6">
          <div
            role="tablist"
            aria-label={t.title}
            className="inline-flex flex-wrap items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg"
          >
            {platformTabs.map((tab) => {
              const isActive = selectedPlatform === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={isActive}
                  onClick={() => setSelectedPlatform(tab.id)}
                  className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] ${
                    isActive
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-sm'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div aria-live="polite" aria-label={t.loadingLabel}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {[0, 1, 2, 3, 4, 5].map((idx) => (
                <div
                  key={idx}
                  className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3 animate-pulse"
                >
                  <div className="h-3.5 w-32 bg-slate-200 dark:bg-slate-800 rounded" />
                  <div className="h-5 w-4/5 bg-slate-200 dark:bg-slate-800 rounded" />
                  <div className="space-y-2 pt-1">
                    <div className="h-3.5 w-full bg-slate-200 dark:bg-slate-800 rounded" />
                    <div className="h-3.5 w-5/6 bg-slate-200 dark:bg-slate-800 rounded" />
                  </div>
                  <div className="pt-3 border-t border-slate-200 dark:border-slate-800 h-4 w-24 bg-slate-200 dark:bg-slate-800 rounded" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Official Portals Fallback / Error State */}
        {!isLoading && errorMsg && (
          <div className="space-y-6">
            <div className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <p className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-1">
                  {t.errorTitle}
                </p>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {t.sourcesHeading}
                </p>
              </div>
              <button
                type="button"
                onClick={() => void loadNews(selectedPlatform, lang, true)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors cursor-pointer whitespace-nowrap self-start sm:self-center shrink-0"
              >
                <RefreshCw className="w-4 h-4" aria-hidden="true" />
                <span>{t.retryBtn}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(['qiwa', 'absher', 'nafath'] as PlatformId[])
                .filter((pid) => selectedPlatform === 'all' || selectedPlatform === pid)
                .map((pid) => {
                  const platform = PLATFORMS[pid];
                  return (
                    <a
                      key={pid}
                      href={platform.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 rounded-xl p-5 flex flex-col justify-between gap-4 transition-colors"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-2">
                          <span className={`text-xs font-semibold ${platform.accentText}`}>
                            {platform.name[lang]}
                          </span>
                          <span className="font-mono text-[11px] text-slate-400 dark:text-slate-500" dir="ltr">
                            {platform.domainLabel}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                          {platform.tagline[lang]}
                        </p>
                      </div>
                      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400">
                        <span>{t.readSourceLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                      </span>
                    </a>
                  );
                })}
            </div>
          </div>
        )}

        {/* Empty State */}
        {!isLoading && !errorMsg && items.length === 0 && (
          <div className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center">
            <p className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 mb-2">
              {t.emptyTitle}
            </p>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-md mx-auto mb-5">
              {t.emptyDesc}
            </p>
            <button
              type="button"
              onClick={() => void loadNews(selectedPlatform, lang, true)}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <RefreshCw className="w-4 h-4" aria-hidden="true" />
              <span>{t.refreshBtn}</span>
            </button>
          </div>
        )}

        {/* Populated News Cards */}
        {!isLoading && !errorMsg && items.length > 0 && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {items.map((item) => {
                const platform = PLATFORMS[item.platform];
                return (
                  <article
                    key={item.id}
                    className="bg-[#F8FAFC] dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-5 flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-3 min-w-0">
                        <span className={`font-semibold ${platform.accentText} whitespace-nowrap`}>
                          {platform.name[lang]}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">{item.category}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums whitespace-nowrap">{item.dateLabel}</span>
                      </div>

                      <h3 className="font-display text-base font-semibold text-slate-900 dark:text-slate-100 leading-snug mb-2.5">
                        {item.title}
                      </h3>

                      <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                        {item.summary}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                      <a
                        href={item.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#0F6E4A] dark:text-emerald-400 hover:text-[#0B563A] dark:hover:text-emerald-300 transition-colors whitespace-nowrap"
                      >
                        <span>{t.readSourceLabel}</span>
                        <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
                      </a>
                    </div>
                  </article>
                );
              })}
            </div>

            {/* Grounded Search Sources Strip */}
            <div className="pt-6 border-t border-slate-200 dark:border-slate-800">
              <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mb-3">
                {t.sourcesHeading}
              </p>
              {sources.length > 0 ? (
                <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {sources.map((src) => (
                    <li key={src.uri}>
                      <a
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center justify-between gap-2 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-[#F8FAFC] dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700 text-xs text-slate-700 dark:text-slate-300 transition-colors"
                      >
                        <span className="truncate font-medium">{src.title}</span>
                        <ExternalLink
                          className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0"
                          aria-hidden="true"
                        />
                      </a>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-xs text-slate-500 dark:text-slate-400">{t.sourcesEmpty}</p>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
