import React from 'react';
import { Bookmark } from 'lucide-react';
import { LanguageCode } from '../types/guide';
import { NEWS_STRINGS } from '../data/newsStrings';
import { UI_STRINGS } from '../data/uiStrings';

interface HeaderProps {
  lang: LanguageCode;
  savedCount: number;
  onOpenSaved: () => void;
}

export const Header: React.FC<HeaderProps> = ({ lang, savedCount, onOpenSaved }) => {
  const t = UI_STRINGS[lang];
  const newsT = NEWS_STRINGS[lang];

  return (
    <header className="sticky top-0 z-30 bg-[#F8FAFC]/95 dark:bg-slate-950/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 pt-[env(safe-area-inset-top)]">
      <div className="max-w-[1200px] mx-auto px-3.5 sm:px-6 h-15 sm:h-16 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <a
          href="#top"
          className="font-display text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-slate-100 whitespace-nowrap truncate min-w-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
        >
          {t.brandTitle}
        </a>

        {/* Zone 2: 5 Concise Single-Line Navigation Links */}
        <nav
          aria-label={t.brandTitle}
          className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300"
        >
          <a
            href="#directory"
            className="hover:text-slate-900 dark:hover:text-white hover:underline underline-offset-8 decoration-slate-300 dark:decoration-slate-600 transition-colors whitespace-nowrap shrink-0 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
          >
            {t.navDirectory}
          </a>
          <a
            href="#updates"
            className="hover:text-slate-900 dark:hover:text-white hover:underline underline-offset-8 decoration-slate-300 dark:decoration-slate-600 transition-colors whitespace-nowrap shrink-0 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
          >
            {newsT.navLabel}
          </a>
          <a
            href="#journeys"
            className="hover:text-slate-900 dark:hover:text-white hover:underline underline-offset-8 decoration-slate-300 dark:decoration-slate-600 transition-colors whitespace-nowrap shrink-0 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
          >
            {t.navJourneys}
          </a>
          <a
            href="#comparison"
            className="hover:text-slate-900 dark:hover:text-white hover:underline underline-offset-8 decoration-slate-300 dark:decoration-slate-600 transition-colors whitespace-nowrap shrink-0 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
          >
            {t.navComparison}
          </a>
          <a
            href="#faq"
            className="hover:text-slate-900 dark:hover:text-white hover:underline underline-offset-8 decoration-slate-300 dark:decoration-slate-600 transition-colors whitespace-nowrap shrink-0 py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0F6E4A] rounded"
          >
            {t.navFaq}
          </a>
        </nav>

        {/* Zone 3: 1 Primary Action Button */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onOpenSaved}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-[#0F6E4A] hover:bg-[#0B563A] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[#0F6E4A]"
          >
            <Bookmark className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.myServicesBtn}</span>
            <span className="tabular-nums font-mono text-xs opacity-90">({savedCount})</span>
          </button>
        </div>
      </div>
    </header>
  );
};
