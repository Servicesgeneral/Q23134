import { Capacitor, type PluginListenerHandle } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdPluginEvents,
  BannerAdPosition,
  BannerAdSize,
  InterstitialAdPluginEvents,
  type AdMobBannerSize,
} from '@capacitor-community/admob';
import { AD_CONFIG } from '../config/admobRuntimeConfig';

const INTERSTITIAL_COOLDOWN_MS = 120_000;
const INTERSTITIAL_EVERY_N_VIEWS = 3;

let initialized = false;
let bannerLoaded = false;
let bannerCurrentlyHidden = false;
let lastBannerHeight = 0;
let interstitialReady = false;
let interstitialLoading = false;
let lastInterstitialShownAt = 0;
let serviceCloseCount = 0;
let heightCallback: ((height: number) => void) | null = null;

async function preloadInterstitial(): Promise<void> {
  if (!Capacitor.isNativePlatform() || interstitialReady || interstitialLoading) return;
  interstitialLoading = true;
  try {
    await AdMob.prepareInterstitial({
      adId: AD_CONFIG.interstitialAdId,
      isTesting: AD_CONFIG.isTesting,
    });
    interstitialReady = true;
  } catch {
    interstitialReady = false;
  } finally {
    interstitialLoading = false;
  }
}

export async function initAdMob(onBannerHeightChange: (heightPx: number) => void): Promise<() => void> {
  heightCallback = onBannerHeightChange;

  if (!Capacitor.isNativePlatform()) {
    onBannerHeightChange(0);
    return () => {
      heightCallback = null;
    };
  }

  const handles: PluginListenerHandle[] = [];

  try {
    if (!initialized) {
      await AdMob.initialize({
        initializeForTesting: AD_CONFIG.isTesting,
      });
      initialized = true;
    }

    try {
      const consentInfo = await AdMob.requestConsentInfo();
      if (
        consentInfo.isConsentFormAvailable &&
        consentInfo.status === AdmobConsentStatus.REQUIRED
      ) {
        await AdMob.showConsentForm();
      }
    } catch {
      // Consent form not configured or offline; continue safely
    }

    handles.push(
      await AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size: AdMobBannerSize) => {
        lastBannerHeight = size.height || 0;
        if (!bannerCurrentlyHidden) {
          heightCallback?.(lastBannerHeight);
        }
      }),
    );

    handles.push(
      await AdMob.addListener(BannerAdPluginEvents.FailedToLoad, () => {
        bannerLoaded = false;
        lastBannerHeight = 0;
        heightCallback?.(0);
      }),
    );

    handles.push(
      await AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => {
        interstitialReady = false;
        void preloadInterstitial();
      }),
    );

    handles.push(
      await AdMob.addListener(InterstitialAdPluginEvents.FailedToShow, () => {
        interstitialReady = false;
        void preloadInterstitial();
      }),
    );

    await AdMob.showBanner({
      adId: AD_CONFIG.bannerAdId,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: AD_CONFIG.isTesting,
    });
    bannerLoaded = true;
    bannerCurrentlyHidden = false;

    void preloadInterstitial();
  } catch {
    onBannerHeightChange(0);
  }

  return () => {
    heightCallback = null;
    for (const handle of handles) {
      void handle.remove();
    }
  };
}

export async function setBannerVisible(visible: boolean): Promise<void> {
  if (!Capacitor.isNativePlatform() || !bannerLoaded) return;

  try {
    if (!visible && !bannerCurrentlyHidden) {
      await AdMob.hideBanner();
      bannerCurrentlyHidden = true;
      heightCallback?.(0);
    } else if (visible && bannerCurrentlyHidden) {
      await AdMob.resumeBanner();
      bannerCurrentlyHidden = false;
      heightCallback?.(lastBannerHeight);
    }
  } catch {
    // Ignore native state race errors
  }
}

export async function maybeShowInterstitialAfterServiceView(): Promise<void> {
  if (!Capacitor.isNativePlatform() || !initialized) return;

  serviceCloseCount += 1;
  const now = Date.now();
  const enoughViews = serviceCloseCount % INTERSTITIAL_EVERY_N_VIEWS === 0;
  const cooldownPassed = now - lastInterstitialShownAt >= INTERSTITIAL_COOLDOWN_MS;

  if (!enoughViews || !cooldownPassed) {
    if (!interstitialReady) {
      void preloadInterstitial();
    }
    return;
  }

  if (!interstitialReady) {
    void preloadInterstitial();
    return;
  }

  try {
    lastInterstitialShownAt = now;
    interstitialReady = false;
    await AdMob.showInterstitial();
  } catch {
    interstitialReady = false;
    void preloadInterstitial();
  }
}
