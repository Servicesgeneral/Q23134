import { LanguageCode } from '../types/guide';

export interface NewsStrings {
  navLabel: string;
  kicker: string;
  title: string;
  subtitle: string;
  allTab: string;
  refreshBtn: string;
  refreshingLabel: string;
  lastUpdatedLabel: string;
  cachedLabel: string;
  liveLabel: string;
  readSourceLabel: string;
  sourcesHeading: string;
  sourcesEmpty: string;
  loadingLabel: string;
  errorTitle: string;
  retryBtn: string;
  emptyTitle: string;
  emptyDesc: string;
}

export const NEWS_STRINGS: Record<LanguageCode, NewsStrings> = {
  ar: {
    navLabel: 'التحديثات الرسمية',
    kicker: 'آخر المستجدات والإعلانات',
    title: 'أحدث إعلانات وتحديثات قوى وأبشر ونفاذ',
    subtitle:
      'جلب مباشر لأحدث القرارات والخدمات الجديدة والتحديثات المعلنة عبر البحث الفوري في المصادر الرسمية والإخبارية المعتمدة.',
    allTab: 'جميع المنصات',
    refreshBtn: 'تحديث الأخبار',
    refreshingLabel: 'جاري البحث والتحديث...',
    lastUpdatedLabel: 'آخر تحديث:',
    cachedLabel: 'محدّث مؤقتاً',
    liveLabel: 'بحث حي مباشر',
    readSourceLabel: 'عرض المصدر',
    sourcesHeading: 'المصادر المستخلصة عبر بحث Google',
    sourcesEmpty: 'روابط المصادر الرسمية متاحة في كل بطاقة تحديث أعلاه.',
    loadingLabel: 'جاري جلب أحدث التحديثات الرسمية...',
    errorTitle: 'تعذّر جلب التحديثات الحية حالياً',
    retryBtn: 'إعادة المحاولة',
    emptyTitle: 'لا توجد تحديثات معروضة حالياً',
    emptyDesc: 'اضغط على تحديث الأخبار لجلب أحدث الإعلانات الرسمية لهذه المنصة.',
  },
  en: {
    navLabel: 'Official Updates',
    kicker: 'Live Official Updates',
    title: 'Latest Announcements from Qiwa, Absher & Nafath',
    subtitle:
      'Real-time updates on newly launched e-services, labor regulations, and portal announcements retrieved via Google Search grounding.',
    allTab: 'All Platforms',
    refreshBtn: 'Refresh Updates',
    refreshingLabel: 'Searching latest updates...',
    lastUpdatedLabel: 'Updated:',
    cachedLabel: 'Cached result',
    liveLabel: 'Live search',
    readSourceLabel: 'Read Source',
    sourcesHeading: 'Grounded Search Sources',
    sourcesEmpty: 'Official portal links are attached to each announcement card above.',
    loadingLabel: 'Fetching the latest official announcements...',
    errorTitle: 'Unable to load live updates right now',
    retryBtn: 'Retry',
    emptyTitle: 'No updates displayed',
    emptyDesc: 'Click Refresh Updates to fetch the latest announcements for this platform.',
  },
  ur: {
    navLabel: 'تازہ اپڈیٹس',
    kicker: 'تازہ ترین سرکاری اعلانات',
    title: 'قوى، ابشر اور نفاذ کی تازہ ترین خبریں اور اپڈیٹس',
    subtitle:
      'نئی ای سروسز، لیبر قوانین اور سرکاری اعلانات کی تازہ معلومات براہِ راست گوگل سرچ گراؤنڈنگ کے ذریعے۔',
    allTab: 'تمام پلیٹ فارمز',
    refreshBtn: 'تازہ کریں',
    refreshingLabel: 'تازہ معلومات تلاش کی جا رہی ہیں...',
    lastUpdatedLabel: 'آخری اپڈیٹ:',
    cachedLabel: 'محفوظ شدہ نتیجہ',
    liveLabel: 'لائیو سرچ',
    readSourceLabel: 'ماخذ دیکھیں',
    sourcesHeading: 'گوگل سرچ سے حاصل کردہ ذرائع',
    sourcesEmpty: 'ہر کارڈ میں سرکاری ماخذ کا لنک موجود ہے۔',
    loadingLabel: 'تازہ ترین سرکاری اعلانات لوڈ ہو رہے ہیں...',
    errorTitle: 'اس وقت تازہ اپڈیٹس لوڈ نہیں ہو سکیں',
    retryBtn: 'دوبارہ کوشش کریں',
    emptyTitle: 'کوئی اپڈیٹ دستیاب نہیں',
    emptyDesc: 'تازہ ترین اعلانات دیکھنے کے لیے تازہ کریں پر کلک کریں۔',
  },
  bn: {
    navLabel: 'সর্বশেষ আপডেট',
    kicker: 'সাম্প্রতিক সরকারি ঘোষণা',
    title: 'ক্বিওয়া, আবশের ও নাফাযের সর্বশেষ আপডেট ও ঘোষণা',
    subtitle:
      'গুগল সার্চ গ্রাউন্ডিংয়ের মাধ্যমে নতুন ই-সেবা, শ্রম বিধিমালা এবং অফিসিয়াল ঘোষণার রিয়েল-টাইম তথ্য।',
    allTab: 'সকল প্ল্যাটফর্ম',
    refreshBtn: 'আপডেট রিফ্রেশ',
    refreshingLabel: 'সর্বশেষ তথ্য খোঁজা হচ্ছে...',
    lastUpdatedLabel: 'সর্বশেষ আপডেট:',
    cachedLabel: 'ক্যাশকৃত তথ্য',
    liveLabel: 'লাইভ সার্চ',
    readSourceLabel: 'মূল সূত্র দেখুন',
    sourcesHeading: 'গুগল সার্চ থেকে প্রাপ্ত সূত্রসমূহ',
    sourcesEmpty: 'উপরের প্রতিটি কার্ডে অফিসিয়াল সূত্রের লিংক যুক্ত রয়েছে।',
    loadingLabel: 'সর্বশেষ সরকারি ঘোষণাগুলো লোড হচ্ছে...',
    errorTitle: 'এই মুহূর্তে লাইভ আপডেট লোড করা যায়নি',
    retryBtn: 'আবার চেষ্টা করুন',
    emptyTitle: 'কোনো আপডেট প্রদর্শিত হচ্ছে না',
    emptyDesc: 'এই প্ল্যাটফর্মের সর্বশেষ ঘোষণা পেতে আপডেট রিফ্রেশ বাটনে ক্লিক করুন।',
  },
};
