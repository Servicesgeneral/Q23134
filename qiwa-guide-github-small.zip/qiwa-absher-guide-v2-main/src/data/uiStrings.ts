import { AudienceKey, LanguageCode, LanguageMeta } from '../types/guide';

export const LANGUAGES: LanguageMeta[] = [
  { code: 'ar', nativeLabel: 'العربية', dir: 'rtl' },
  { code: 'en', nativeLabel: 'English', dir: 'ltr' },
  { code: 'ur', nativeLabel: 'اردو', dir: 'rtl' },
  { code: 'bn', nativeLabel: 'বাংলা', dir: 'ltr' },
];

export interface UiStrings {
  brandTitle: string;
  navDirectory: string;
  navJourneys: string;
  navComparison: string;
  navFaq: string;
  myServicesBtn: string;

  // Workspace Utility Bar & Compliance
  languageLabel: string;
  darkModeLabel: string;
  lightModeLabel: string;
  disclaimerBannerPrefix: string;
  disclaimerBannerText: string;
  viewComplianceBtn: string;

  // Hero
  heroKicker: string;
  heroTitle: string;
  heroSubtitle: string;
  heroSearchCta: string;
  heroJourneysCta: string;
  heroImageAlt: string;
  heroCaption: string;
  statPlatformsLabel: string;
  statPlatformsValue: string;
  statPlatformsSub: string;
  statServicesLabel: string;
  statServicesUnit: string;
  statServicesSub: string;
  statJourneysLabel: string;
  statJourneysValue: string;
  statJourneysSub: string;
  statChecklistLabel: string;
  statChecklistValue: string;
  statChecklistSub: string;

  // Directory
  dirKicker: string;
  dirTitle: string;
  dirShowingPrefix: string;
  dirShowingSuffix: string;
  tabAllPlatforms: string;
  searchPlaceholder: string;
  searchAriaLabel: string;
  clearSearchAria: string;
  audienceLabel: string;
  audienceOptions: Record<AudienceKey, string>;
  resetFiltersBtn: string;
  emptyTitle: string;
  emptyDesc: string;
  emptyCta: string;
  cardAudiencePrefix: string;
  cardDurationPrefix: string;
  cardNafathRequired: string;
  cardDirectAccess: string;
  cardActionLabel: string;
  cardReadyPrefix: string;
  cardReqSuffix: string;
  saveServiceAria: string;
  unsaveServiceAria: string;

  // Journeys
  journeysKicker: string;
  journeysTitle: string;
  journeysSubtitle: string;
  stagesCountSuffix: string;
  stagePrefix: string;
  journeyAudiencePrefix: string;
  journeyTimePrefix: string;
  serviceDetailsLink: string;

  // Comparison Table
  compKicker: string;
  compTitle: string;
  compSubtitle: string;
  colCode: string;
  colService: string;
  colPlatform: string;
  colAudience: string;
  colDuration: string;
  colFee: string;
  colNafath: string;
  colAction: string;
  nafathYes: string;
  nafathNo: string;
  viewLabel: string;

  // FAQ
  faqKicker: string;
  faqTitle: string;
  faqSubtitle: string;

  // Service Detail Drawer
  savedBadge: string;
  saveBtn: string;
  closeDrawerAria: string;
  factAudience: string;
  factDuration: string;
  factNafath: string;
  factFee: string;
  reqHeading: string;
  reqProgressPrefix: string;
  reqProgressOf: string;
  reqResetBtn: string;
  stepsHeading: string;
  notesHeading: string;
  connectedPlatformsLabel: string;
  goToOfficialPrefix: string;
  goToOfficialSuffix: string;
  closeBtn: string;

  // Saved Drawer
  savedTitle: string;
  savedCountSuffix: string;
  savedEmptyTitle: string;
  savedEmptyDesc: string;
  savedEmptyCta: string;
  savedReadinessPrefix: string;
  openDetailsBtn: string;
  removeSavedAria: string;

  // Compliance / Legal / Privacy Modal
  complianceTitle: string;
  complianceSubtitle: string;
  disclaimerSectionTitle: string;
  disclaimerFullText: string;
  sourcesSectionTitle: string;
  sourcesDescription: string;
  officialSourcesList: Array<{ name: string; org: string; url: string }>;
  privacySectionTitle: string;
  privacyPoints: string[];

  // Footer
  footerSummary: string;
  footerOfficialLinksTitle: string;
  footerLegalLinksTitle: string;
  footerNotice: string;
  footerLegalBtn: string;
}

export const UI_STRINGS: Record<LanguageCode, UiStrings> = {
  ar: {
    brandTitle: 'دليل الخدمات الرقمية',
    navDirectory: 'الدليل الشامل',
    navJourneys: 'رحلات التكامل',
    navComparison: 'مقارنة الإجراءات',
    navFaq: 'الأسئلة الشائعة',
    myServicesBtn: 'قائمة خدماتي',

    languageLabel: 'اللغة',
    darkModeLabel: 'الوضع المظلم',
    lightModeLabel: 'الوضع الفاتح',
    disclaimerBannerPrefix: 'تنويه مستقل:',
    disclaimerBannerText:
      'هذا التطبيق دليل إرشادي ومعلوماتي مستقل غير تابع لأي جهة حكومية، وتُنفذ جميع المعاملات حصرياً عبر البوابات الرسمية.',
    viewComplianceBtn: 'إخلاء المسؤولية والخصوصية والمصادر',

    heroKicker: 'دليل إرشادي مستقل للخدمات الرقمية · المملكة العربية السعودية',
    heroTitle: 'دليل خدمات منصة قوى وأبشر ونفاذ في مرجع واحد متكامل',
    heroSubtitle:
      'استعرض المتطلبات النظامية، خطوات التنفيذ التفصيلية، الرسوم الرسمية، ومسارات الربط بين النفاذ الوطني الموحد وخدمات الداخلية وسوق العمل بوضوح تام.',
    heroSearchCta: 'ابحث في الخدمات',
    heroJourneysCta: 'مسارات التكامل بين المنصات',
    heroImageAlt: 'مبنى معماري حديث في الرياض يعبر عن البنية الرقمية الحديثة',
    heroCaption: 'معلومات استرشادية مستمدة من المصادر الرسمية المعلنة لمنصات قوى وأبشر ونفاذ.',
    statPlatformsLabel: 'المنصات المشمولة',
    statPlatformsValue: '3 منصات وطنية',
    statPlatformsSub: 'قوى · أبشر · نفاذ',
    statServicesLabel: 'الخدمات الموثقة',
    statServicesUnit: 'خدمة تفصيلية',
    statServicesSub: 'للأفراد والمنشآت والمقيمين',
    statJourneysLabel: 'مسارات العمل المشتركة',
    statJourneysValue: '4 رحلات مترابطة',
    statJourneysSub: 'توضيح تسلسل الربط الفعلي',
    statChecklistLabel: 'قوائم التحقق التفاعلية',
    statChecklistValue: 'تجهيز مسبق للوثائق',
    statChecklistSub: 'حفظ محلي آمن دون حساب',

    dirKicker: '01. الدليل التفاعلي للخدمات',
    dirTitle: 'استكشف خدمات قوى وأبشر ونفاذ',
    dirShowingPrefix: 'عرض',
    dirShowingSuffix: 'خدمة مطابقة',
    tabAllPlatforms: 'جميع المنصات',
    searchPlaceholder: 'ابحث باسم الخدمة أو الكلمة المفتاحية (مثل: عقد عمل، إقامة)...',
    searchAriaLabel: 'البحث في الخدمات',
    clearSearchAria: 'مسح البحث',
    audienceLabel: 'الفئة المستفيدة:',
    audienceOptions: {
      all: 'جميع المستفيدين',
      individuals: 'الأفراد',
      establishments: 'المنشآت والأعمال',
      residents: 'المقيمون',
    },
    resetFiltersBtn: 'إعادة ضبط الفلاتر',
    emptyTitle: 'لم يتم العثور على خدمات مطابقة لبحثك',
    emptyDesc: 'جرّب البحث بكلمات أوسع مثل «إقامة»، «تأشيرة»، «عقد»، أو أعد ضبط الفلاتر لعرض جميع الخدمات.',
    emptyCta: 'عرض جميع الخدمات',
    cardAudiencePrefix: 'المستفيد:',
    cardDurationPrefix: 'المدة:',
    cardNafathRequired: 'يتطلب نفاذ',
    cardDirectAccess: 'دخول مباشر',
    cardActionLabel: 'المتطلبات وخطوات التنفيذ',
    cardReadyPrefix: 'جاهزية',
    cardReqSuffix: 'متطلبات',
    saveServiceAria: 'حفظ الخدمة في قائمة خدماتي',
    unsaveServiceAria: 'إزالة الخدمة من قائمة خدماتي',

    journeysKicker: '02. كيف تتكامل المنصات معاً',
    journeysTitle: 'مسارات الإجراءات المشتركة بين قوى وأبشر ونفاذ',
    journeysSubtitle:
      'كثير من المعاملات تتطلب التنقل بين أكثر من منصة بترتيب محدد. اختر السيناريو لمعرفة نقطة البداية والربط الآلي بين الأنظمة.',
    stagesCountSuffix: 'مراحل',
    stagePrefix: 'المرحلة',
    journeyAudiencePrefix: 'الفئة:',
    journeyTimePrefix: 'المدة المقدرة:',
    serviceDetailsLink: 'تفاصيل الخدمة',

    compKicker: '03. مرجع الرسوم والمدد القياسية',
    compTitle: 'مقارنة سريعة لأبرز الإجراءات والرسوم',
    compSubtitle:
      'جدول مرجعي يوضح المنصة المسؤولة، الفئة المستهدفة، المدة المتوقعة، والرسوم النظامية المعلنة مع إمكانية استعراض التفاصيل مباشرة.',
    colCode: 'الرمز',
    colService: 'الخدمة',
    colPlatform: 'المنصة',
    colAudience: 'المستفيد',
    colDuration: 'المدة التقريبية',
    colFee: 'الرسوم الرسمية',
    colNafath: 'نفاذ',
    colAction: 'التفاصيل',
    nafathYes: 'مطلوب',
    nafathNo: 'غير مطلوب',
    viewLabel: 'عرض',

    faqKicker: '04. إجابات عملية',
    faqTitle: 'الأسئلة الشائعة حول الربط والتوثيق',
    faqSubtitle:
      'توضيحات مباشرة لأكثر العقبات التي يواجهها الأفراد وأصحاب العمل عند تنفيذ المعاملات بين قوى وأبشر ونفاذ.',

    savedBadge: 'محفوظة',
    saveBtn: 'حفظ',
    closeDrawerAria: 'إغلاق تفاصيل الخدمة',
    factAudience: 'الفئة المستفيدة',
    factDuration: 'المدة المتوقعة',
    factNafath: 'المصادقة عبر نفاذ',
    factFee: 'الرسوم النظامية',
    reqHeading: 'المتطلبات والشروط المسبقة',
    reqProgressPrefix: 'حدّد المتطلبات الجاهزة لديك: تم تجهيز',
    reqProgressOf: 'من',
    reqResetBtn: 'إعادة تعيين',
    stepsHeading: 'خطوات تنفيذ الخدمة',
    notesHeading: 'ملاحظات هامة والتكامل مع المنصات',
    connectedPlatformsLabel: 'المنصات المرتبطة بهذه الخدمة:',
    goToOfficialPrefix: 'الانتقال إلى',
    goToOfficialSuffix: 'الرسمية',
    closeBtn: 'إغلاق',

    savedTitle: 'قائمة خدماتي',
    savedCountSuffix: 'خدمات محفوظة للمتابعة',
    savedEmptyTitle: 'قائمة خدماتي فارغة حالياً',
    savedEmptyDesc:
      'اضغط على أيقونة الحفظ في أي خدمة داخل الدليل لإضافتها هنا ومتابعة جاهزية متطلباتها.',
    savedEmptyCta: 'تصفح الدليل',
    savedReadinessPrefix: 'جاهزية المتطلبات:',
    openDetailsBtn: 'فتح التفاصيل',
    removeSavedAria: 'إزالة من المحفوظات',

    complianceTitle: 'إخلاء المسؤولية، المصادر الرسمية، وسياسة الخصوصية',
    complianceSubtitle: 'بيان الشفافية والامتثال لسياسات متجر Google Play والإعلانات والأنظمة المحلية',
    disclaimerSectionTitle: '1. إخلاء المسؤولية وعدم الانتماء الحكومي',
    disclaimerFullText:
      'يُعد «دليل الخدمات الرقمية» تطبيقاً إرشادياً ومعلوماتياً مستقلاً تماماً، ولا يتبع ولا يمثل ولا يحظى برعاية أو اعتماد أي جهة حكومية في المملكة العربية السعودية (بما في ذلك وزارة الموارد البشرية والتنمية الاجتماعية، أو وزارة الداخلية، أو الهيئة السعودية للبيانات والذكاء الاصطناعي «سدايا»، أو منصات قوى وأبشر ونفاذ). الغرض الوحيد من هذا التطبيق هو مساعدة المستخدمين والمقيمين وأصحاب العمل على فهم الشروط والمتطلبات والخطوات العامة قبل التوجه لتنفيذ معاملاتهم مباشرة عبر المواقع الرسمية المعتمدة. جميع العلامات والأسماء التجارية المذكورة مملوكة لأصحابها وتُذكر لغرض التعريف الإرشادي فقط.',
    sourcesSectionTitle: '2. المصادر الرسمية للمعلومات',
    sourcesDescription:
      'تم تجميع وتنسيق الشروحات الواردة في هذا الدليل من البوابات الحكومية الرسمية المتاحة للجمهور في المملكة العربية السعودية. يُرجى دائماً مراجعة البوابات الرسمية التالية للتحقق من أحدث الرسوم واللوائح قبل تنفيذ أي إجراء:',
    officialSourcesList: [
      {
        name: 'منصة قوى — وزارة الموارد البشرية والتنمية الاجتماعية',
        org: 'qiwa.sa · hrsd.gov.sa',
        url: 'https://www.qiwa.sa',
      },
      {
        name: 'منصة أبشر — وزارة الداخلية',
        org: 'absher.sa · moi.gov.sa',
        url: 'https://www.absher.sa',
      },
      {
        name: 'منصة النفاذ الوطني الموحد (نفاذ) — سدايا',
        org: 'iam.gov.sa · sdaia.gov.sa',
        url: 'https://www.iam.gov.sa',
      },
    ],
    privacySectionTitle: '3. سياسة الخصوصية وحماية البيانات',
    privacyPoints: [
      'عدم جمع بيانات الهوية أو كلمات المرور: لا يطلب التطبيق مطلقاً إدخال رقم الهوية الوطنية أو الإقامة أو كلمات مرور أبشر أو نفاذ أو أي بيانات مالية، وتُجرى جميع المعاملات الفعلية خارج التطبيق على الروابط الرسمية الحكومية.',
      'التخزين المحلي على الجهاز: تُحفظ قائمة الخدمات المفضلة وحالة مربعات التحقق للمتطلبات محلياً داخل متصفح/جهاز المستخدم فقط (Local Storage) ولا تُرسل إلى أي خادم خارجي.',
      'الإعلانات وخدمات الطرف الثالث (Google AdMob / AdSense): في حال تفعيل الإعلانات في النسخة المنشورة، قد تستخدم شبكة إعلانات Google معرّف الإعلانات الخاص بالجهاز أو ملفات تعريف الارتباط لعرض إعلانات متوافقة مع سياسات الخصوصية، مع إمكانية إدارة تفضيلات الخصوصية والموافقة من إعدادات الجهاز.',
      'تحديث البيانات: يتم تحديث المعلومات الإرشادية دورياً، ومع ذلك تبقى البوابات الرسمية هي المرجع النهائي والملزم لأي رسوم أو شروط نظامية.',
    ],

    footerSummary:
      'دليل إرشادي مستقل يوضح إجراءات وشروط منصات قوى وأبشر ونفاذ. غير تابع لأي جهة حكومية، وتُنفذ كافة المعاملات حصرياً عبر البوابات الرسمية.',
    footerOfficialLinksTitle: 'المصادر والبوابات الرسمية',
    footerLegalLinksTitle: 'الشفافية والامتثال',
    footerNotice:
      'تطبيق إرشادي مستقل · غير تابع لجهة حكومية · الرسوم والشروط خاضعة للتحديث في البوابات الرسمية.',
    footerLegalBtn: 'إخلاء المسؤولية وسياسة الخصوصية والمصادر',
  },

  en: {
    brandTitle: 'Digital Services Guide',
    navDirectory: 'Directory',
    navJourneys: 'Workflows',
    navComparison: 'Fee & Time Table',
    navFaq: 'FAQ',
    myServicesBtn: 'Saved List',

    languageLabel: 'Language',
    darkModeLabel: 'Dark Mode',
    lightModeLabel: 'Light Mode',
    disclaimerBannerPrefix: 'Independent Notice:',
    disclaimerBannerText:
      'This app is an independent informational guide not affiliated with any Saudi government entity. All official transactions are performed solely on official portals.',
    viewComplianceBtn: 'Disclaimer, Sources & Privacy Policy',

    heroKicker: 'Independent Informational Guide · Kingdom of Saudi Arabia',
    heroTitle: 'Complete Guide to Qiwa, Absher & Nafath Services',
    heroSubtitle:
      'Explore requirements, step-by-step procedures, official fees, and how National Single Sign-On (Nafath), Ministry of Interior (Absher), and Labor (Qiwa) connect in practice.',
    heroSearchCta: 'Search Services',
    heroJourneysCta: 'Cross-Platform Workflows',
    heroImageAlt: 'Contemporary architectural pavilion in Riyadh representing modern digital infrastructure',
    heroCaption: 'Informational reference compiled from publicly available official portals of Qiwa, Absher, and Nafath.',
    statPlatformsLabel: 'Platforms Covered',
    statPlatformsValue: '3 National Portals',
    statPlatformsSub: 'Qiwa · Absher · Nafath',
    statServicesLabel: 'Documented Procedures',
    statServicesUnit: 'Detailed Services',
    statServicesSub: 'Individuals, Businesses & Residents',
    statJourneysLabel: 'Combined Workflows',
    statJourneysValue: '4 End-to-End Paths',
    statJourneysSub: 'Step-by-step system handoffs',
    statChecklistLabel: 'Interactive Checklists',
    statChecklistValue: 'Document Readiness',
    statChecklistSub: 'Saved locally with zero login',

    dirKicker: '01. Interactive Directory',
    dirTitle: 'Explore Qiwa, Absher & Nafath Services',
    dirShowingPrefix: 'Showing',
    dirShowingSuffix: 'matching services',
    tabAllPlatforms: 'All Platforms',
    searchPlaceholder: 'Search by service name or keyword (e.g., iqama, contract, visa)...',
    searchAriaLabel: 'Search services',
    clearSearchAria: 'Clear search',
    audienceLabel: 'Beneficiary:',
    audienceOptions: {
      all: 'All Audiences',
      individuals: 'Individuals',
      establishments: 'Businesses & Employers',
      residents: 'Residents (Expats)',
    },
    resetFiltersBtn: 'Reset Filters',
    emptyTitle: 'No matching services found',
    emptyDesc: 'Try broader keywords such as "iqama", "visa", or "contract", or reset filters to view all documented services.',
    emptyCta: 'Show All Services',
    cardAudiencePrefix: 'For:',
    cardDurationPrefix: 'Est. Time:',
    cardNafathRequired: 'Nafath Required',
    cardDirectAccess: 'Direct Access',
    cardActionLabel: 'Requirements & Steps',
    cardReadyPrefix: 'Ready',
    cardReqSuffix: 'requirements',
    saveServiceAria: 'Save service to Saved List',
    unsaveServiceAria: 'Remove service from Saved List',

    journeysKicker: '02. How Portals Connect',
    journeysTitle: 'Cross-Platform Workflows Across Qiwa, Absher & Nafath',
    journeysSubtitle:
      'Many procedures require sequential actions across multiple portals. Select a scenario to inspect the exact starting point and handoffs.',
    stagesCountSuffix: 'stages',
    stagePrefix: 'Stage',
    journeyAudiencePrefix: 'Audience:',
    journeyTimePrefix: 'Est. Duration:',
    serviceDetailsLink: 'Service Details',

    compKicker: '03. Standard Fees & Timelines Reference',
    compTitle: 'Quick Comparison of Key Procedures & Fees',
    compSubtitle:
      'Reference table summarizing the responsible portal, target audience, estimated processing time, and standard official fees.',
    colCode: 'Code',
    colService: 'Service',
    colPlatform: 'Platform',
    colAudience: 'Audience',
    colDuration: 'Est. Time',
    colFee: 'Official Fee',
    colNafath: 'Nafath',
    colAction: 'Details',
    nafathYes: 'Required',
    nafathNo: 'Not Required',
    viewLabel: 'View',

    faqKicker: '04. Practical Answers',
    faqTitle: 'Frequently Asked Questions',
    faqSubtitle:
      'Clear answers to the most common challenges faced by residents, citizens, and employers using Qiwa, Absher, and Nafath.',

    savedBadge: 'Saved',
    saveBtn: 'Save',
    closeDrawerAria: 'Close service details',
    factAudience: 'Target Audience',
    factDuration: 'Est. Duration',
    factNafath: 'Nafath Verification',
    factFee: 'Official Fees',
    reqHeading: 'Prerequisites & Requirements',
    reqProgressPrefix: 'Mark ready documents:',
    reqProgressOf: 'of',
    reqResetBtn: 'Reset',
    stepsHeading: 'Step-by-Step Procedure',
    notesHeading: 'Important Notes & Integration',
    connectedPlatformsLabel: 'Connected Platforms:',
    goToOfficialPrefix: 'Open Official',
    goToOfficialSuffix: 'Portal',
    closeBtn: 'Close',

    savedTitle: 'Saved Services List',
    savedCountSuffix: 'services saved for tracking',
    savedEmptyTitle: 'Your Saved List is empty',
    savedEmptyDesc:
      'Click the bookmark icon on any service card to save it here and track your document readiness.',
    savedEmptyCta: 'Browse Directory',
    savedReadinessPrefix: 'Readiness:',
    openDetailsBtn: 'Open Details',
    removeSavedAria: 'Remove from saved',

    complianceTitle: 'Disclaimer, Official Sources & Privacy Policy',
    complianceSubtitle: 'Transparency statement for Google Play Console, AdMob/AdSense & local regulatory compliance',
    disclaimerSectionTitle: '1. Government Non-Affiliation Disclaimer',
    disclaimerFullText:
      'Digital Services Guide is a strictly independent informational and educational reference application. It is NOT affiliated with, endorsed by, sponsored by, or representing any government agency in the Kingdom of Saudi Arabia (including the Ministry of Human Resources and Social Development, Ministry of Interior, SDAIA, Qiwa, Absher, or Nafath). Its sole purpose is to help users understand prerequisites and steps before completing transactions directly on official government portals. All official trademarks belong to their respective owners.',
    sourcesSectionTitle: '2. Official Information Sources',
    sourcesDescription:
      'All guides are compiled from publicly accessible Saudi government portals. Always verify current fees, rules, and eligibility directly on the official sources listed below:',
    officialSourcesList: [
      {
        name: 'Qiwa Platform — Ministry of Human Resources & Social Development',
        org: 'qiwa.sa · hrsd.gov.sa',
        url: 'https://www.qiwa.sa',
      },
      {
        name: 'Absher Platform — Ministry of Interior',
        org: 'absher.sa · moi.gov.sa',
        url: 'https://www.absher.sa',
      },
      {
        name: 'Nafath (National Single Sign-On) — SDAIA',
        org: 'iam.gov.sa · sdaia.gov.sa',
        url: 'https://www.iam.gov.sa',
      },
    ],
    privacySectionTitle: '3. Privacy Policy & Data Safety',
    privacyPoints: [
      'No Government Credentials Collected: This app never asks for National IDs, Iqama numbers, Absher/Nafath passwords, OTPs, or payment details. Official tasks are performed externally on official government websites.',
      'Local Device Storage Only: Your bookmarked services and requirement checklist progress are stored strictly locally on your device (Local Storage) and are never transmitted to external servers.',
      'Third-Party Advertising (Google AdMob / AdSense): When ads are enabled in published builds, Google advertising SDKs may use device advertising IDs or cookies in accordance with Google Privacy & Consent policies.',
      'Information Accuracy: Content is reviewed periodically, though official government portals remain the sole authoritative reference for current fees and regulations.',
    ],

    footerSummary:
      'Independent informational guide explaining Qiwa, Absher, and Nafath workflows. Not affiliated with any government agency; transactions occur exclusively on official portals.',
    footerOfficialLinksTitle: 'Official Government Portals',
    footerLegalLinksTitle: 'Transparency & Compliance',
    footerNotice:
      'Independent guide · Not a government entity · Fees and regulations are subject to updates on official portals.',
    footerLegalBtn: 'Disclaimer, Privacy Policy & Sources',
  },

  ur: {
    brandTitle: 'ڈیجیٹل سروسز گائیڈ',
    navDirectory: 'مکمل ڈائریکٹری',
    navJourneys: 'مشترکہ مراحل',
    navComparison: 'فیس اور وقت کا جدول',
    navFaq: 'عام سوالات',
    myServicesBtn: 'محفوظ فہرست',

    languageLabel: 'زبان',
    darkModeLabel: 'ڈارک موڈ',
    lightModeLabel: 'لائٹ موڈ',
    disclaimerBannerPrefix: 'آزاد وضاحت:',
    disclaimerBannerText:
      'یہ ایپ ایک آزاد معلوماتی گائیڈ ہے اور کسی سعودی سرکاری ادارے سے منسلک نہیں ہے۔ تمام سرکاری کام صرف سرکاری ویب سائٹس پر انجام پاتے ہیں۔',
    viewComplianceBtn: 'دستبرداری، ذرائع اور پرائیویسی پالیسی',

    heroKicker: 'آزاد معلوماتی گائیڈ · مملکتِ سعودی عرب',
    heroTitle: 'قوى، ابشر اور نفاذ سروسز کی مکمل رہنمائی ایک جگہ',
    heroSubtitle:
      'سعودی عرب میں ملازمت کے معاہدوں، اقامہ، ویزا اور ڈیجیٹل تصدیق کے لیے قوى، ابشر اور نفاذ کی شرائط، مراحل اور سرکاری فیسوں کی تفصیلات جانیں۔',
    heroSearchCta: 'سروسز تلاش کریں',
    heroJourneysCta: 'پلیٹ فارمز کے مشترکہ مراحل',
    heroImageAlt: 'ریاض کی جدید عمارت جو جدید ڈیجیٹل نظام کی عکاسی کرتی ہے',
    heroCaption: 'قوى، ابشر اور نفاذ کے عوامی سرکاری پورٹلز سے حاصل کردہ رہنما معلومات۔',
    statPlatformsLabel: 'شامل پلیٹ فارمز',
    statPlatformsValue: '3 قومی پورٹلز',
    statPlatformsSub: 'قوى · ابشر · نفاذ',
    statServicesLabel: 'دستاویزی خدمات',
    statServicesUnit: 'تفصیلی خدمات',
    statServicesSub: 'افراد، کمپنیوں اور مقیمین کے لیے',
    statJourneysLabel: 'مشترکہ طریقہ کار',
    statJourneysValue: '4 مکمل مراحل',
    statJourneysSub: 'نظاموں کا باہمی ربط',
    statChecklistLabel: 'تیاری کی فہرست',
    statChecklistValue: 'دستاویزات کی جانچ',
    statChecklistSub: 'بغیر لاگ ان کے محفوظ',

    dirKicker: '01. انٹرایکٹو ڈائریکٹری',
    dirTitle: 'قوى، ابشر اور نفاذ کی خدمات دریافت کریں',
    dirShowingPrefix: 'کل',
    dirShowingSuffix: 'متعلقہ خدمات',
    tabAllPlatforms: 'تمام پلیٹ فارمز',
    searchPlaceholder: 'سروس کا نام یا لفظ لکھیں (مثلاً: اقامہ، معاہدہ، کفالہ)...',
    searchAriaLabel: 'خدمات تلاش کریں',
    clearSearchAria: 'تلاش صاف کریں',
    audienceLabel: 'مستفید فرد:',
    audienceOptions: {
      all: 'تمام صارفین',
      individuals: 'افراد',
      establishments: 'کاروبار اور کمپنیاں',
      residents: 'مقیمین (غیر ملکی)',
    },
    resetFiltersBtn: 'فلٹرز ری سیٹ کریں',
    emptyTitle: 'کوئی متعلقہ سروس نہیں ملی',
    emptyDesc: 'آسان الفاظ استعمال کریں جیسے «اقامہ»، «ویزا» یا «معاہدہ»، یا تمام خدمات دیکھنے کے لیے فلٹرز صاف کریں۔',
    emptyCta: 'تمام خدمات دکھائیں',
    cardAudiencePrefix: 'برائے:',
    cardDurationPrefix: 'وقت:',
    cardNafathRequired: 'نفاذ درکار',
    cardDirectAccess: 'براہِ راست رسائی',
    cardActionLabel: 'شرائط اور طریقہ کار',
    cardReadyPrefix: 'تیاری',
    cardReqSuffix: 'شرائط',
    saveServiceAria: 'فہرست میں محفوظ کریں',
    unsaveServiceAria: 'فہرست سے ہٹائیں',

    journeysKicker: '02. پلیٹ فارمز کا باہمی ربط',
    journeysTitle: 'قوى، ابشر اور نفاذ کے مشترکہ مراحل',
    journeysSubtitle:
      'کئی کاموں کے لیے ایک سے زیادہ پلیٹ فارم پر ترتیب وار کارروائی ضروری ہوتی ہے۔ مکمل سلسلہ دیکھنے کے لیے مرحلہ منتخب کریں۔',
    stagesCountSuffix: 'مراحل',
    stagePrefix: 'مرحلہ',
    journeyAudiencePrefix: 'برائے:',
    journeyTimePrefix: 'اندازاً وقت:',
    serviceDetailsLink: 'سروس کی تفصیلات',

    compKicker: '03. فیس اور وقت کا حوالہ',
    compTitle: 'اہم خدمات اور سرکاری فیسوں کا موازنہ',
    compSubtitle:
      'ذمہ دار پلیٹ فارم، متوقع وقت اور سرکاری فیسوں کا خلاصہ جدول، تفصیلات دیکھنے کے لیے کلک کریں۔',
    colCode: 'کوڈ',
    colService: 'سروس',
    colPlatform: 'پلیٹ فارم',
    colAudience: 'صارف',
    colDuration: 'متوقع وقت',
    colFee: 'سرکاری فیس',
    colNafath: 'نفاذ',
    colAction: 'تفصیل',
    nafathYes: 'درکار',
    nafathNo: 'غیر ضروری',
    viewLabel: 'دیکھیں',

    faqKicker: '04. عملی جوابات',
    faqTitle: 'تصدیق اور ربط سے متعلق عام سوالات',
    faqSubtitle:
      'قوى، ابشر اور نفاذ استعمال کرتے وقت پیش آنے والے عام مسائل کے واضح جوابات۔',

    savedBadge: 'محفوظ',
    saveBtn: 'محفوظ کریں',
    closeDrawerAria: 'تفصیلات بند کریں',
    factAudience: 'مستفید طبقہ',
    factDuration: 'متوقع وقت',
    factNafath: 'نفاذ تصدیق',
    factFee: 'سرکاری فیس',
    reqHeading: 'ضروری شرائط اور دستاویزات',
    reqProgressPrefix: 'تیار شدہ شرائط منتخب کریں:',
    reqProgressOf: 'از',
    reqResetBtn: 'ری سیٹ',
    stepsHeading: 'عملدرآمد کے مراحل',
    notesHeading: 'اہم نوٹس اور باہمی ربط',
    connectedPlatformsLabel: 'متعلقہ پلیٹ فارمز:',
    goToOfficialPrefix: 'سرکاری',
    goToOfficialSuffix: 'پورٹل کھولیں',
    closeBtn: 'بند کریں',

    savedTitle: 'میری محفوظ خدمات',
    savedCountSuffix: 'محفوظ خدمات',
    savedEmptyTitle: 'محفوظ فہرست فی الحال خالی ہے',
    savedEmptyDesc:
      'کسی بھی سروس کارڈ پر محفوظ کرنے کا بٹن دبائیں تاکہ آپ اپنی تیاری کا جائزہ لے سکیں۔',
    savedEmptyCta: 'ڈائریکٹری دیکھیں',
    savedReadinessPrefix: 'تیاری:',
    openDetailsBtn: 'تفصیل کھولیں',
    removeSavedAria: 'فہرست سے ہٹائیں',

    complianceTitle: 'دستبرداری، سرکاری ذرائع اور پرائیویسی پالیسی',
    complianceSubtitle: 'Google Play Console، اشتہارات اور مقامی قوانین کے مطابق شفافیت کا بیان',
    disclaimerSectionTitle: '1. سرکاری عدم وابستگی کا اعلان (Disclaimer)',
    disclaimerFullText:
      '«ڈیجیٹل سروسز گائیڈ» ایک مکمل طور پر آزاد معلوماتی اور تعلیمی ایپ ہے، جو مملکتِ سعودی عرب کے کسی بھی سرکاری ادارے (بشمول وزارتِ انسانی وسائل، وزارتِ داخلہ، سدایا، قوى، ابشر یا نفاذ) کی نمائندگی نہیں کرتی اور نہ ہی ان سے منسلک ہے۔ اس کا مقصد صرف صارفین کو سرکاری ویب سائٹس پر کارروائی کرنے سے پہلے شرائط اور طریقہ کار سمجھنے میں مدد دینا ہے۔',
    sourcesSectionTitle: '2. معلومات کے سرکاری ذرائع',
    sourcesDescription:
      'اس گائیڈ میں شامل تمام معلومات سعودی عرب کے عوامی سرکاری پورٹلز سے لی گئی ہیں۔ حتمی فیسوں اور قوانین کی تصدیق کے لیے ہمیشہ درج ذیل سرکاری ویب سائٹس دیکھیں:',
    officialSourcesList: [
      {
        name: 'قوى پلیٹ فارم — وزارتِ انسانی وسائل و سماجی ترقی',
        org: 'qiwa.sa · hrsd.gov.sa',
        url: 'https://www.qiwa.sa',
      },
      {
        name: 'ابشر پلیٹ فارم — وزارتِ داخلہ',
        org: 'absher.sa · moi.gov.sa',
        url: 'https://www.absher.sa',
      },
      {
        name: 'نفاذ (نیشنل سنگل سائن آن) — سدایا',
        org: 'iam.gov.sa · sdaia.gov.sa',
        url: 'https://www.iam.gov.sa',
      },
    ],
    privacySectionTitle: '3. پرائیویسی پالیسی اور ڈیٹا تحفظ',
    privacyPoints: [
      'کوئی شناختی یا خفیہ ڈیٹا جمع نہیں کیا جاتا: یہ ایپ کبھی بھی اقامہ نمبر، شناختی کارڈ یا ابشر/نفاذ کے پاس ورڈ طلب نہیں کرتی۔ تمام سرکاری کام ایپ سے باہر سرکاری ویب سائٹس پر ہوتے ہیں۔',
      'صرف ڈیوائس پر محفوظ: آپ کی محفوظ خدمات اور چیک لسٹ صرف آپ کے اپنے براؤزر/ڈیوائس (Local Storage) میں محفوظ رہتی ہے۔',
      'گوگل اشتہارات (Google AdMob / AdSense): شائع شدہ ورژن میں اشتہارات فعال ہونے پر گوگل اشتہاری نیٹ ورک پرائیویسی پالیسی کے تحت ڈیوائس کا ایڈورٹائزنگ آئی ڈی استعمال کر سکتا ہے۔',
      'معلومات کی درستگی: مواد وقتاً فوقتاً اپڈیٹ کیا جاتا ہے، تاہم حتمی اتھارٹی صرف سرکاری ویب سائٹس ہیں۔',
    ],

    footerSummary:
      'قوى، ابشر اور نفاذ کی خدمات کی وضاحت کرنے والی آزاد معلوماتی گائیڈ۔ کسی سرکاری ادارے سے منسلک نہیں۔',
    footerOfficialLinksTitle: 'سرکاری ویب سائٹس',
    footerLegalLinksTitle: 'شفافیت اور پالیسی',
    footerNotice:
      'آزاد گائیڈ · سرکاری ایپ نہیں · فیس اور شرائط سرکاری ویب سائٹس پر تبدیلی سے مشروط ہیں۔',
    footerLegalBtn: 'دستبرداری، پرائیویسی پالیسی اور ذرائع',
  },

  bn: {
    brandTitle: 'ডিজিটাল সেবা গাইড',
    navDirectory: 'সেবা ডিরেক্টরি',
    navJourneys: 'সমন্বিত ধাপ',
    navComparison: 'ফি ও সময় তালিকা',
    navFaq: 'সাধারণ প্রশ্ন',
    myServicesBtn: 'সংরক্ষিত তালিকা',

    languageLabel: 'ভাষা',
    darkModeLabel: 'ডার্ক মোড',
    lightModeLabel: 'লাইট মোড',
    disclaimerBannerPrefix: 'স্বতন্ত্র বিজ্ঞপ্তি:',
    disclaimerBannerText:
      'এই অ্যাপটি একটি স্বতন্ত্র তথ্যমূলক গাইড এবং কোনো সৌদি সরকারি সংস্থার সাথে যুক্ত নয়। সকল সরকারি কাজ শুধুমাত্র অফিসিয়াল পোর্টালে সম্পন্ন হয়।',
    viewComplianceBtn: 'দাবিত্যাগ, সরকারি সূত্র ও গোপনীয়তা নীতি',

    heroKicker: 'স্বতন্ত্র তথ্যমূলক গাইড · সৌদি আরব',
    heroTitle: 'ক্বিওয়া, আবশের ও নাফায সেবার সম্পূর্ণ নির্দেশিকা',
    heroSubtitle:
      'কাজের চুক্তি, ইকামা নবায়ন, ভিসা এবং ডিজিটাল যাচাইকরণের জন্য ক্বিওয়া (Qiwa), আবশের (Absher) ও নাফায (Nafath)-এর প্রয়োজনীয় শর্ত, ধাপ এবং সরকারি ফি সম্পর্কে বিস্তারিত জানুন।',
    heroSearchCta: 'সেবা খুঁজুন',
    heroJourneysCta: 'সমন্বিত কর্মপ্রবাহ',
    heroImageAlt: 'রিয়াদের আধুনিক স্থাপত্য যা আধুনিক ডিজিটাল অবকাঠামোকে নির্দেশ করে',
    heroCaption: 'ক্বিওয়া, আবশের এবং নাফাযের উন্মুক্ত অফিসিয়াল পোর্টাল থেকে সংকলিত তথ্যমূলক নির্দেশিকা।',
    statPlatformsLabel: 'অন্তর্ভুক্ত প্ল্যাটফর্ম',
    statPlatformsValue: '৩টি জাতীয় পোর্টাল',
    statPlatformsSub: 'ক্বিওয়া · আবশের · নাফায',
    statServicesLabel: 'নথিভুক্ত সেবা',
    statServicesUnit: 'বিস্তারিত সেবা',
    statServicesSub: 'ব্যক্তি, প্রতিষ্ঠান ও প্রবাসীদের জন্য',
    statJourneysLabel: 'যৌথ কর্মপ্রবাহ',
    statJourneysValue: '৪টি সম্পূর্ণ ধাপ',
    statJourneysSub: 'সিস্টেমগুলোর পারস্পরিক সংযোগ',
    statChecklistLabel: 'প্রস্তুতি তালিকা',
    statChecklistValue: 'কাগজপত্র যাচাই',
    statChecklistSub: 'লগইন ছাড়াই ডিভাইসে সংরক্ষিত',

    dirKicker: '০১. ইন্টারঅ্যাক্টিভ ডিরেক্টরি',
    dirTitle: 'ক্বিওয়া, আবশের এবং নাফায সেবা খুঁজুন',
    dirShowingPrefix: 'প্রদর্শিত হচ্ছে',
    dirShowingSuffix: 'টি সেবা',
    tabAllPlatforms: 'সকল প্ল্যাটফর্ম',
    searchPlaceholder: 'সেবার নাম বা শব্দ লিখুন (যেমন: ইকামা, চুক্তি, ভিসা)...',
    searchAriaLabel: 'সেবা খুঁজুন',
    clearSearchAria: 'অনুসন্ধান মুছুন',
    audienceLabel: 'সুবিধাভোগী:',
    audienceOptions: {
      all: 'সকল ব্যবহারকারী',
      individuals: 'ব্যক্তিগত',
      establishments: 'প্রতিষ্ঠান ও নিয়োগকর্তা',
      residents: 'প্রবাসী (রেসিডেন্ট)',
    },
    resetFiltersBtn: 'ফিল্টার রিসেট',
    emptyTitle: 'কোনো মিল খুঁজে পাওয়া যায়নি',
    emptyDesc: '“ইকামা”, “ভিসা” বা “চুক্তি” এর মতো সহজ শব্দ ব্যবহার করুন অথবা সব সেবা দেখতে ফিল্টার রিসেট করুন।',
    emptyCta: 'সকল সেবা দেখুন',
    cardAudiencePrefix: 'যাদের জন্য:',
    cardDurationPrefix: 'সময়:',
    cardNafathRequired: 'নাফায প্রয়োজন',
    cardDirectAccess: 'সরাসরি প্রবেশ',
    cardActionLabel: 'শর্ত ও ধাপসমূহ',
    cardReadyPrefix: 'প্রস্তুত',
    cardReqSuffix: 'টি শর্ত',
    saveServiceAria: 'সংরক্ষিত তালিকায় যোগ করুন',
    unsaveServiceAria: 'সংরক্ষিত তালিকা থেকে সরান',

    journeysKicker: '০২. প্ল্যাটফর্মগুলোর সংযোগ',
    journeysTitle: 'ক্বিওয়া, আবশের এবং নাফাযের সমন্বিত কর্মপ্রবাহ',
    journeysSubtitle:
      'অনেক কাজ সম্পন্ন করতে একাধিক পোর্টালে ধারাবাহিক ধাপ অনুসরণ করতে হয়। সঠিক ক্রম জানতে একটি পরিস্থিতি নির্বাচন করুন।',
    stagesCountSuffix: 'টি ধাপ',
    stagePrefix: 'ধাপ',
    journeyAudiencePrefix: 'যাদের জন্য:',
    journeyTimePrefix: 'আনুমানিক সময়:',
    serviceDetailsLink: 'সেবার বিস্তারিত',

    compKicker: '০৩. ফি ও সময়সূচি নির্দেশিকা',
    compTitle: 'প্রধান সেবা ও সরকারি ফির তুলনা',
    compSubtitle:
      'দায়িত্বপ্রাপ্ত পোর্টাল, আনুমানিক সময় এবং নির্ধারিত সরকারি ফির সংক্ষিপ্ত তালিকা।',
    colCode: 'কোড',
    colService: 'সেবা',
    colPlatform: 'প্ল্যাটফর্ম',
    colAudience: 'সুবিধাভোগী',
    colDuration: 'আনুমানিক সময়',
    colFee: 'সরকারি ফি',
    colNafath: 'নাফায',
    colAction: 'বিস্তারিত',
    nafathYes: 'প্রয়োজন',
    nafathNo: 'প্রয়োজন নেই',
    viewLabel: 'দেখুন',

    faqKicker: '০৪. ব্যবহারিক উত্তর',
    faqTitle: 'সাধারণ জিজ্ঞাসিত প্রশ্নাবলী',
    faqSubtitle:
      'ক্বিওয়া, আবশের এবং নাফায ব্যবহারের সময় প্রবাসী ও নিয়োগকর্তাদের সবচেয়ে সাধারণ প্রশ্নের উত্তর।',

    savedBadge: 'সংরক্ষিত',
    saveBtn: 'সংরক্ষণ',
    closeDrawerAria: 'বিস্তারিত বন্ধ করুন',
    factAudience: 'সুবিধাভোগী',
    factDuration: 'আনুমানিক সময়',
    factNafath: 'নাফায যাচাই',
    factFee: 'সরকারি ফি',
    reqHeading: 'প্রয়োজনীয় শর্ত ও কাগজপত্র',
    reqProgressPrefix: 'প্রস্তুত শর্ত চিহ্নিত করুন:',
    reqProgressOf: 'এর মধ্যে',
    reqResetBtn: 'রিসেট',
    stepsHeading: 'কাজ করার ধাপসমূহ',
    notesHeading: 'গুরুত্বপূর্ণ নোট ও সমন্বয়',
    connectedPlatformsLabel: 'সংযুক্ত প্ল্যাটফর্ম:',
    goToOfficialPrefix: 'অফিসিয়াল',
    goToOfficialSuffix: 'পোর্টালে যান',
    closeBtn: 'বন্ধ করুন',

    savedTitle: 'সংরক্ষিত সেবার তালিকা',
    savedCountSuffix: 'টি সেবা সংরক্ষিত',
    savedEmptyTitle: 'সংরক্ষিত তালিকাটি বর্তমানে খালি',
    savedEmptyDesc:
      'কাগজপত্রের প্রস্তুতি ট্র্যাক করতে যেকোনো সেবার বুকমার্ক আইকনে ক্লিক করে এখানে সংরক্ষণ করুন।',
    savedEmptyCta: 'ডিরেক্টরি দেখুন',
    savedReadinessPrefix: 'প্রস্তুতি:',
    openDetailsBtn: 'বিস্তারিত খুলুন',
    removeSavedAria: 'তালিকা থেকে সরান',

    complianceTitle: 'দাবিত্যাগ, সরকারি সূত্র ও গোপনীয়তা নীতি',
    complianceSubtitle: 'Google Play Console, বিজ্ঞাপন এবং স্থানীয় বিধিমালা মেনে চলার স্বচ্ছতা বিবৃতি',
    disclaimerSectionTitle: '১. সরকারি অ-সংশ্লিষ্টতা ঘোষণা (Disclaimer)',
    disclaimerFullText:
      '«ডিজিটাল সেবা গাইড» একটি সম্পূর্ণ স্বতন্ত্র তথ্যমূলক ও শিক্ষামূলক অ্যাপ। এটি সৌদি আরব সরকারের কোনো মন্ত্রণালয় বা সংস্থা (যেমন: মানবসম্পদ মন্ত্রণালয়, স্বরাষ্ট্র মন্ত্রণালয়, SDAIA, ক্বিওয়া, আবশের বা নাফায)-এর সাথে যুক্ত নয় বা তাদের প্রতিনিধিত্ব করে না। এর একমাত্র উদ্দেশ্য হলো ব্যবহারকারীদের অফিসিয়াল পোর্টালে আবেদন করার আগে শর্ত ও ধাপগুলো বুঝতে সাহায্য করা।',
    sourcesSectionTitle: '২. তথ্যের সরকারি সূত্র',
    sourcesDescription:
      'এই গাইডের তথ্যসমূহ সৌদি আরবের উন্মুক্ত সরকারি পোর্টাল থেকে সংকলিত। সর্বশেষ ফি ও নিয়ম যাচাই করতে সর্বদা নিচের অফিসিয়াল ওয়েবসাইট দেখুন:',
    officialSourcesList: [
      {
        name: 'ক্বিওয়া পোর্টাল — মানবসম্পদ ও সামাজিক উন্নয়ন মন্ত্রণালয়',
        org: 'qiwa.sa · hrsd.gov.sa',
        url: 'https://www.qiwa.sa',
      },
      {
        name: 'আবশের পোর্টাল — স্বরাষ্ট্র মন্ত্রণালয়',
        org: 'absher.sa · moi.gov.sa',
        url: 'https://www.absher.sa',
      },
      {
        name: 'নাফায (ন্যাশনাল সিঙ্গেল সাইন-অন) — SDAIA',
        org: 'iam.gov.sa · sdaia.gov.sa',
        url: 'https://www.iam.gov.sa',
      },
    ],
    privacySectionTitle: '৩. গোপনীয়তা নীতি ও ডেটা সুরক্ষা',
    privacyPoints: [
      'কোনো পরিচয়পত্র বা পাসওয়ার্ড সংগ্রহ করা হয় না: এই অ্যাপ কখনোই ইকামা নম্বর, জাতীয় পরিচয়পত্র বা আবশের/নাফায পাসওয়ার্ড চায় না। সকল কাজ সরাসরি সরকারি ওয়েবসাইটে সম্পন্ন হয়।',
      'শুধুমাত্র ডিভাইসে সংরক্ষণ: আপনার বুকমার্ক ও চেকলিস্টের তথ্য শুধুমাত্র আপনার নিজের ব্রাউজার/ডিভাইসে (Local Storage) সংরক্ষিত থাকে।',
      'বিজ্ঞাপন সেবা (Google AdMob / AdSense): প্রকাশিত সংস্করণে বিজ্ঞাপন চালু থাকলে Google বিজ্ঞাপন নীতিমালা অনুযায়ী ডিভাইসের বিজ্ঞাপন আইডি ব্যবহার করতে পারে।',
      'তথ্যের নির্ভুলতা: তথ্য নিয়মিত পর্যালোচনা করা হয়, তবে চূড়ান্ত ফি ও শর্তের জন্য অফিসিয়াল পোর্টালই চূড়ান্ত উৎস।',
    ],

    footerSummary:
      'ক্বিওয়া, আবশের ও নাফাযের কার্যপ্রণালী বোঝার জন্য স্বতন্ত্র তথ্যমূলক গাইড। কোনো সরকারি সংস্থার অ্যাপ নয়; সকল কার্যক্রম অফিসিয়াল পোর্টালে সম্পন্ন হয়।',
    footerOfficialLinksTitle: 'অফিসিয়াল সরকারি পোর্টাল',
    footerLegalLinksTitle: 'স্বচ্ছতা ও নীতিমালা',
    footerNotice:
      'স্বতন্ত্র গাইড · সরকারি অ্যাপ নয় · ফি ও নিয়মাবলী অফিসিয়াল পোর্টালে পরিবর্তনশীল।',
    footerLegalBtn: 'দাবিত্যাগ, গোপনীয়তা নীতি ও সূত্র',
  },
};
