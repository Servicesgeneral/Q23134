export interface AdMobRuntimeConfig {
  appName: string;
  androidPackageId: string;
  admobAppId: string;
  bannerAdId: string;
  interstitialAdId: string;
  isTesting: boolean;
  newsApiBaseUrl: string;
}

// Auto-synced from /admob-settings.json during Android/GitHub builds
export const AD_CONFIG: AdMobRuntimeConfig = {
  appName: 'دليل خدمات قوى وأبشر ونفاذ',
  androidPackageId: 'com.saudiguide.services',
  admobAppId: 'ca-app-pub-3940256099942544~3347511713',
  bannerAdId: 'ca-app-pub-3940256099942544/6300978111',
  interstitialAdId: 'ca-app-pub-3940256099942544/1033173712',
  isTesting: true,
  newsApiBaseUrl: 'https://ais-pre-pa5hjses5qnl5nijm6ounx-228809946359.europe-west3.run.app',
};
