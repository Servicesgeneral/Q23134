export type LanguageCode = 'ar' | 'en' | 'ur' | 'bn';

export type PlatformId = 'qiwa' | 'absher' | 'nafath';

export type AudienceKey = 'individuals' | 'establishments' | 'residents' | 'all';

export type LocalizedText = Record<LanguageCode, string>;
export type LocalizedList = Record<LanguageCode, string[]>;

export interface LanguageMeta {
  code: LanguageCode;
  nativeLabel: string;
  dir: 'rtl' | 'ltr';
}

export interface PlatformInfo {
  id: PlatformId;
  name: LocalizedText;
  shortName: LocalizedText;
  entity: LocalizedText;
  tagline: LocalizedText;
  description: LocalizedText;
  officialUrl: string;
  domainLabel: string;
  accentText: string;
}

export interface ServiceItem {
  id: string;
  code: string;
  title: LocalizedText;
  platform: PlatformId;
  category: LocalizedText;
  audience: AudienceKey;
  summary: LocalizedText;
  duration: LocalizedText;
  fee: LocalizedText;
  officialUrl: string;
  requiresNafath: boolean;
  connectedPlatforms: PlatformId[];
  requirements: LocalizedList;
  steps: LocalizedList;
  notes: LocalizedText;
  keywords: string[];
}

export interface JourneyStage {
  stepNumber: string;
  platform: PlatformId;
  title: LocalizedText;
  action: LocalizedText;
  relatedServiceId?: string;
}

export interface UserJourney {
  id: string;
  title: LocalizedText;
  audience: LocalizedText;
  summary: LocalizedText;
  estimatedTotalTime: LocalizedText;
  stages: JourneyStage[];
}

export interface FaqItem {
  id: string;
  question: LocalizedText;
  answer: LocalizedText;
  platforms: PlatformId[];
}

export interface NewsUpdateItem {
  id: string;
  platform: PlatformId;
  title: string;
  summary: string;
  dateLabel: string;
  category: string;
  sourceUrl: string;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface NewsApiResponse {
  items: NewsUpdateItem[];
  sources: GroundingSource[];
  fetchedAt: string;
  cached: boolean;
}
