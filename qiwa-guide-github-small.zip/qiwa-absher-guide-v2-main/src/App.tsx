/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { ComparisonTable } from './components/ComparisonTable';
import { ComplianceModal } from './components/ComplianceModal';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { JourneysSection } from './components/JourneysSection';
import { MobileBottomNav } from './components/MobileBottomNav';
import { NewsFeedSection } from './components/NewsFeedSection';
import { SavedServicesDrawer } from './components/SavedServicesDrawer';
import { ServiceDetailDrawer } from './components/ServiceDetailDrawer';
import { ServiceDirectory } from './components/ServiceDirectory';
import { SERVICES } from './data/servicesPart2';
import { LANGUAGES, UI_STRINGS } from './data/uiStrings';
import {
  initAdMob,
  maybeShowInterstitialAfterServiceView,
  setBannerVisible,
} from './services/admobService';
import {
  AudienceKey,
  LanguageCode,
  PlatformId,
  ServiceItem,
} from './types/guide';

const SAVED_STORAGE_KEY = 'saudi_services_saved_v1';
const CHECKS_STORAGE_KEY = 'saudi_services_checks_v1';
const LANG_STORAGE_KEY = 'saudi_services_lang_v1';
const THEME_STORAGE_KEY = 'saudi_services_theme_v1';

// Normalize Arabic text so common letter variants and tashkeel do not block search.
const normalizeSearchText = (value: string) =>
  value
    .toLocaleLowerCase()
    .normalize('NFKC')
    .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي');

export default function App() {
  const [lang, setLang] = useState<LanguageCode>(() => {
    try {
      const stored = localStorage.getItem(LANG_STORAGE_KEY) as LanguageCode | null;
      if (stored && ['ar', 'en', 'ur', 'bn'].includes(stored)) {
        return stored;
      }
    } catch {
      // Ignore storage errors
    }
    return 'ar';
  });

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(THEME_STORAGE_KEY);
      if (stored === 'dark') return true;
      if (stored === 'light') return false;
      return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
    } catch {
      return false;
    }
  });

  const [selectedPlatform, setSelectedPlatform] = useState<PlatformId | 'all'>('all');
  const [selectedAudience, setSelectedAudience] = useState<AudienceKey>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeService, setActiveService] = useState<ServiceItem | null>(null);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);
  const [isComplianceOpen, setIsComplianceOpen] = useState(false);
  const [bannerHeight, setBannerHeight] = useState(0);

  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const [savedIds, setSavedIds] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(SAVED_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch {
      return [];
    }
  });

  const [checkedRequirements, setCheckedRequirements] = useState<Record<string, boolean[]>>(() => {
    try {
      const raw = localStorage.getItem(CHECKS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as Record<string, boolean[]>) : {};
    } catch {
      return {};
    }
  });

  const activeDir: 'rtl' | 'ltr' = useMemo(() => {
    return LANGUAGES.find((l) => l.code === lang)?.dir ?? 'rtl';
  }, [lang]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = activeDir;
    document.title = `${UI_STRINGS[lang].brandTitle} | Qiwa · Absher · Nafath`;
    try {
      localStorage.setItem(LANG_STORAGE_KEY, lang);
    } catch {
      // Ignore storage errors
    }
  }, [lang, activeDir]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', isDark);
    try {
      localStorage.setItem(THEME_STORAGE_KEY, isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage errors
    }
  }, [isDark]);

  useEffect(() => {
    try {
      localStorage.setItem(SAVED_STORAGE_KEY, JSON.stringify(savedIds));
    } catch {
      // Ignore storage quota errors
    }
  }, [savedIds]);

  useEffect(() => {
    try {
      localStorage.setItem(CHECKS_STORAGE_KEY, JSON.stringify(checkedRequirements));
    } catch {
      // Ignore storage quota errors
    }
  }, [checkedRequirements]);

  useEffect(() => {
    let cleanup: (() => void) | undefined;
    void initAdMob((height) => setBannerHeight(height)).then((fn) => {
      cleanup = fn;
    });
    return () => {
      cleanup?.();
    };
  }, []);

  useEffect(() => {
    const hasOverlay =
      activeService !== null || isSavedDrawerOpen || isComplianceOpen;
    void setBannerVisible(!hasOverlay);
  }, [activeService, isSavedDrawerOpen, isComplianceOpen]);

  const filteredServices = useMemo(() => {
    const query = normalizeSearchText(searchQuery.trim());

    return SERVICES.filter((service) => {
      if (selectedPlatform !== 'all' && service.platform !== selectedPlatform) {
        return false;
      }

      if (
        selectedAudience !== 'all' &&
        service.audience !== selectedAudience &&
        service.audience !== 'all'
      ) {
        return false;
      }

      if (!query) return true;

      const haystack = [
        service.code,
        ...Object.values(service.title),
        ...Object.values(service.summary),
        ...Object.values(service.category),
        ...service.keywords,
      ]
        .join(' ');
      const normalizedHaystack = normalizeSearchText(haystack);

      return normalizedHaystack.includes(query);
    });
  }, [selectedPlatform, selectedAudience, searchQuery]);

  const savedServices = useMemo(
    () => SERVICES.filter((s) => savedIds.includes(s.id)),
    [savedIds],
  );

  const handleToggleSave = (id: string) => {
    setSavedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id],
    );
  };

  const handleToggleRequirement = (serviceId: string, index: number) => {
    const targetService = SERVICES.find((s) => s.id === serviceId);
    const total = targetService ? targetService.requirements[lang].length : 0;

    setCheckedRequirements((prev) => {
      const current = prev[serviceId]
        ? [...prev[serviceId]]
        : Array.from({ length: total }, () => false);
      current[index] = !current[index];
      return { ...prev, [serviceId]: current };
    });
  };

  const handleResetRequirements = (serviceId: string) => {
    setCheckedRequirements((prev) => {
      const next = { ...prev };
      delete next[serviceId];
      return next;
    });
  };

  const handleSelectPlatformAndScroll = (platform: PlatformId) => {
    setSelectedPlatform(platform);
    const dirEl = document.getElementById('directory');
    if (dirEl) {
      dirEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleFocusSearch = () => {
    const dirEl = document.getElementById('directory');
    if (dirEl) {
      dirEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setTimeout(() => {
      searchInputRef.current?.focus();
    }, 300);
  };

  return (
    <div
      dir={activeDir}
      className="min-h-screen w-full max-w-full overflow-x-clip flex flex-col bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-150 pb-16 md:pb-0"
    >
      <a href="#main-content" className="skip-link">تجاوز إلى المحتوى الرئيسي</a>
      <Header
        lang={lang}
        savedCount={savedIds.length}
        onOpenSaved={() => setIsSavedDrawerOpen(true)}
      />

      <main id="main-content" tabIndex={-1} className="flex-1 w-full min-w-0 outline-none">
        <HeroSection
          lang={lang}
          dir={activeDir}
          onChangeLang={setLang}
          isDark={isDark}
          onToggleDark={() => setIsDark((prev) => !prev)}
          totalServices={SERVICES.length}
          onSelectPlatformAndScroll={handleSelectPlatformAndScroll}
          onFocusSearch={handleFocusSearch}
          onOpenCompliance={() => setIsComplianceOpen(true)}
        />

        <ServiceDirectory
          lang={lang}
          dir={activeDir}
          services={filteredServices}
          selectedPlatform={selectedPlatform}
          onPlatformChange={setSelectedPlatform}
          selectedAudience={selectedAudience}
          onAudienceChange={setSelectedAudience}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchInputRef={searchInputRef}
          savedIds={savedIds}
          onToggleSave={handleToggleSave}
          onOpenService={setActiveService}
          checkedRequirements={checkedRequirements}
        />

        <NewsFeedSection lang={lang} />

        <JourneysSection
          lang={lang}
          dir={activeDir}
          onOpenService={setActiveService}
        />

        <ComparisonTable
          lang={lang}
          dir={activeDir}
          onOpenService={setActiveService}
        />

        <FaqSection lang={lang} />
      </main>

      <Footer
        lang={lang}
        onOpenCompliance={() => setIsComplianceOpen(true)}
      />

      {bannerHeight > 0 && (
        <div aria-hidden="true" style={{ height: `${bannerHeight}px` }} />
      )}

      <MobileBottomNav lang={lang} bannerHeight={bannerHeight} />

      <ServiceDetailDrawer
        lang={lang}
        service={activeService}
        onClose={() => {
          setActiveService(null);
          void maybeShowInterstitialAfterServiceView();
        }}
        isSaved={activeService ? savedIds.includes(activeService.id) : false}
        onToggleSave={handleToggleSave}
        checkedState={
          activeService
            ? checkedRequirements[activeService.id] ||
              Array.from({ length: activeService.requirements[lang].length }, () => false)
            : []
        }
        onToggleRequirement={handleToggleRequirement}
        onResetRequirements={handleResetRequirements}
      />

      <SavedServicesDrawer
        lang={lang}
        dir={activeDir}
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        savedServices={savedServices}
        onRemoveSaved={handleToggleSave}
        onOpenService={setActiveService}
        checkedRequirements={checkedRequirements}
      />

      <ComplianceModal
        isOpen={isComplianceOpen}
        onClose={() => setIsComplianceOpen(false)}
        lang={lang}
      />
    </div>
  );
}
