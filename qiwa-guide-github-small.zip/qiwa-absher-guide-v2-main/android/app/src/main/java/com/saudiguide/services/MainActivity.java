package com.saudiguide.services;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
